package com.example.aiagent.data

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

class LocalLlmException(message: String) : Exception(message)

/**
 * Офлайн-ИИ: запускает модель формата .litertlm прямо на телефоне (Google LiteRT-LM).
 * Все операции с движком выполняются в одном отдельном потоке, как требует библиотека.
 */
object LocalLlm {
    private val dispatcher = Executors.newSingleThreadExecutor { r ->
        Thread(null, r, "local-llm", 16L * 1024 * 1024)
    }.asCoroutineDispatcher()

    private var engine: Engine? = null
    private var loadedKey: String? = null

    /** Видит ли загруженная модель фото. Известно только после загрузки. */
    @Volatile
    var supportsImages: Boolean = false
        private set

    /** Максимум символов прошлой переписки, которые отправляем модели вместе с вопросом. */
    private const val HISTORY_BUDGET = 6000
    private const val MESSAGE_LIMIT = 3000

    suspend fun stream(
        cacheDir: String,
        modelPath: String,
        useGpu: Boolean,
        useVision: Boolean,
        systemPrompt: String,
        temperature: Float,
        history: List<ChatMessage>,
        onStatus: (String) -> Unit,
        onDelta: (String) -> Unit,
    ) = withContext(dispatcher) {
        val last = history.lastOrNull() ?: throw LocalLlmException("Нечего отправлять.")
        if (!File(modelPath).exists()) {
            throw LocalLlmException("Файл модели не найден. Выбери модель заново в настройках.")
        }
        val eng = ensureEngine(cacheDir, modelPath, useGpu, useVision, onStatus)

        val images = last.images.filter { File(it).exists() }
        if (images.isNotEmpty() && !supportsImages) {
            throw LocalLlmException(
                "Эта модель не умеет смотреть фото. Выбери мультимодальную модель (например, Gemma) " +
                    "или переключись на Gemini в настройках."
            )
        }

        onStatus("MaterialAgent думает…")
        val conversation = try {
            eng.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(systemPrompt.ifBlank { DEFAULT_SYSTEM_PROMPT }),
                    initialMessages = buildPrior(history.dropLast(1)),
                    samplerConfig = SamplerConfig(topK = 40, topP = 0.95, temperature = temperature.toDouble()),
                )
            )
        } catch (t: Throwable) {
            throw LocalLlmException(friendly(t))
        }

        try {
            val text = last.text.ifBlank { "Что на этом фото?" }
            val flow = if (images.isEmpty()) {
                conversation.sendMessageAsync(text)
            } else {
                val parts = ArrayList<Content>()
                images.forEach { parts.add(Content.ImageFile(it)) }
                parts.add(Content.Text(text))
                conversation.sendMessageAsync(Contents.of(*parts.toTypedArray()))
            }
            var got = false
            flow.collect { chunk ->
                val s = chunk.toString()
                if (s.isNotEmpty()) {
                    got = true
                    onDelta(s)
                }
            }
            if (!got) throw LocalLlmException("Модель вернула пустой ответ. Попробуй переформулировать вопрос.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: LocalLlmException) {
            throw e
        } catch (t: Throwable) {
            throw LocalLlmException(friendly(t))
        } finally {
            withContext(NonCancellable) {
                runCatching { conversation.cancelProcess() }
                delay(100)
                runCatching { conversation.close() }
            }
        }
    }

    /** Освобождает память, занятую моделью. */
    suspend fun unload() = withContext(dispatcher) { closeEngine() }

    private fun ensureEngine(
        cacheDir: String,
        modelPath: String,
        useGpu: Boolean,
        useVision: Boolean,
        onStatus: (String) -> Unit,
    ): Engine {
        val key = "$modelPath|$useGpu|$useVision|${File(modelPath).lastModified()}"
        val current = engine
        if (current != null && loadedKey == key) return current
        closeEngine()

        onStatus("Загружаю модель в память… первый раз это может занять до минуты")
        val backends: List<Boolean> = if (useGpu) listOf(true, false) else listOf(false)
        var lastError: Throwable? = null
        for (gpu in backends) {
            val visionOptions: List<Boolean> = if (useVision) listOf(true, false) else listOf(false)
            for (withVision in visionOptions) {
                try {
                    val backend = if (gpu) Backend.GPU() else Backend.CPU()
                    val config = if (withVision) {
                        EngineConfig(
                            modelPath = modelPath,
                            backend = backend,
                            visionBackend = Backend.CPU(),
                            cacheDir = cacheDir,
                        )
                    } else {
                        EngineConfig(
                            modelPath = modelPath,
                            backend = backend,
                            cacheDir = cacheDir,
                        )
                    }
                    val created = Engine(config)
                    created.initialize()
                    engine = created
                    loadedKey = key
                    supportsImages = withVision
                    return created
                } catch (t: Throwable) {
                    lastError = t
                }
            }
        }
        throw LocalLlmException(friendly(lastError))
    }

    private fun closeEngine() {
        runCatching { engine?.close() }
        engine = null
        loadedKey = null
        supportsImages = false
    }

    /** Прошлая переписка в виде сообщений для модели (только текст, с ограничением по длине). */
    private fun buildPrior(prior: List<ChatMessage>): List<Message> {
        val usable = prior.filter { !it.isError }.mapNotNull { m ->
            val t = m.text.ifBlank { if (m.images.isNotEmpty()) "[фото]" else "" }
            if (t.isBlank()) null else m.role to t.take(MESSAGE_LIMIT)
        }
        var budget = HISTORY_BUDGET
        val picked = ArrayList<Pair<String, String>>()
        for (i in usable.indices.reversed()) {
            val item = usable[i]
            if (budget - item.second.length < 0 && picked.isNotEmpty()) break
            budget -= item.second.length
            picked.add(0, item)
        }
        while (picked.isNotEmpty() && picked.first().first != Role.USER) picked.removeAt(0)
        return picked.map { (role, text) ->
            if (role == Role.USER) Message.user(text) else Message.model(text)
        }
    }

    private fun friendly(t: Throwable?): String {
        val msg = t?.message.orEmpty()
        return when {
            t is OutOfMemoryError || msg.contains("memory", ignoreCase = true) ->
                "Не хватило памяти телефона для этой модели. Выбери модель поменьше или закрой другие приложения."
            t is UnsatisfiedLinkError ->
                "Движок офлайн-ИИ не запустился на этом телефоне (нужен 64-битный процессор)."
            msg.contains("OpenCL", ignoreCase = true) ->
                "Видеоускорение недоступно на этом телефоне. Включи в настройках работу на процессоре."
            msg.isNotBlank() -> "Ошибка офлайн-модели: $msg"
            else -> "Не удалось запустить офлайн-модель. Проверь, что выбран файл .litertlm."
        }
    }
}
