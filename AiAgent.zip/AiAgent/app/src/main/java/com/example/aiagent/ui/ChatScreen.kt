@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.aiagent.ui

import android.content.ActivityNotFoundException
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.aiagent.ChatViewModel
import com.example.aiagent.data.APP_NAME
import com.example.aiagent.data.ChatMessage
import com.example.aiagent.data.Provider
import com.example.aiagent.data.Role
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun ChatScreen(vm: ChatViewModel, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var input by rememberSaveable { mutableStateOf("") }

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    LaunchedEffect(vm.notice) {
        vm.notice?.let {
            snackbar.showSnackbar(it)
            vm.notice = null
        }
    }

    // --- Выбор фото из галереи ---
    val pickMedia = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(ChatViewModel.MAX_IMAGES)
    ) { uris -> vm.attachFromUris(uris) }

    // --- Съёмка на камеру ---
    var cameraUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = cameraUri
        if (ok && uri != null) vm.attachFromUris(listOf(uri))
        cameraUri = null
    }

    fun openCamera() {
        try {
            val dir = File(context.cacheDir, "camera").apply { mkdirs() }
            val file = File(dir, "cam_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            cameraUri = uri
            takePicture.launch(uri)
        } catch (e: ActivityNotFoundException) {
            vm.notice = "Приложение камеры не найдено"
        } catch (e: Exception) {
            vm.notice = "Не удалось открыть камеру"
        }
    }

    val s = vm.settings

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ChatDrawer(
                vm = vm,
                onClose = { scope.launch { drawerState.close() } },
                onOpenSettings = onOpenSettings,
            )
        },
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.surface,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Rounded.Menu, contentDescription = "Меню чатов")
                        }
                    },
                    title = {
                        Column {
                            Text(
                                text = vm.currentTitle.ifEmpty { APP_NAME },
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            SourceSwitcher(vm)
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { vm.newChat() },
                            enabled = vm.messages.isNotEmpty(),
                        ) { Icon(Icons.Rounded.AddComment, contentDescription = "Новый чат") }
                        IconButton(onClick = onOpenSettings) {
                            Icon(Icons.Rounded.Settings, contentDescription = "Настройки")
                        }
                    },
                )
            },
            bottomBar = {
                InputBar(
                    value = input,
                    onValueChange = { input = it },
                    pending = vm.pendingImages,
                    attachBusy = vm.attachBusy,
                    isGenerating = vm.isGenerating,
                    onRemoveImage = vm::removePending,
                    onPickGallery = {
                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    onPickCamera = ::openCamera,
                    onSend = {
                        val before = vm.messages.size
                        vm.send(input)
                        // Поле очищаем только если сообщение реально ушло.
                        if (vm.messages.size > before) input = ""
                    },
                    onStop = vm::stop,
                )
            },
        ) { inner ->
            Box(modifier = Modifier.padding(inner).fillMaxSize()) {
                if (vm.messages.isEmpty()) {
                    EmptyState(
                        provider = s.provider,
                        hasModel = s.hasLocalModel,
                        hasKey = s.apiKey.isNotBlank(),
                        onOpenSettings = onOpenSettings,
                        onSuggestion = { vm.send(it) },
                    )
                } else {
                    val listState = rememberLazyListState()
                    LaunchedEffect(vm.messages.size) { listState.animateScrollToItem(0) }
                    val lastId = vm.messages.lastOrNull()?.id
                    LazyColumn(
                        state = listState,
                        reverseLayout = true,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        items(vm.messages.asReversed(), key = { it.id }) { m ->
                            MessageItem(
                                message = m,
                                isLast = m.id == lastId,
                                isGenerating = vm.isGenerating,
                                statusText = vm.statusText,
                                onCopy = {
                                    clipboard.setText(AnnotatedString(m.text))
                                    vm.notice = "Скопировано"
                                },
                                onRegenerate = vm::regenerate,
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Подпись под названием чата: откуда сейчас берутся ответы. Нажатие открывает переключатель. */
@Composable
private fun SourceSwitcher(vm: ChatViewModel) {
    var open by remember { mutableStateOf(false) }
    val s = vm.settings
    val offline = s.provider == Provider.OFFLINE
    val label = if (offline) {
        "Офлайн · " + if (s.hasLocalModel) s.localModelName.removeSuffix(".litertlm") else "модель не выбрана"
    } else {
        "Gemini · ${s.model}"
    }
    Box {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable { open = true },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
            Icon(
                Icons.Rounded.ArrowDropDown,
                contentDescription = "Выбрать источник ответов",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp),
            )
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Офлайн (на телефоне)") },
                leadingIcon = { Icon(Icons.Rounded.Memory, contentDescription = null) },
                trailingIcon = {
                    if (offline) Icon(Icons.Rounded.Check, contentDescription = null)
                },
                onClick = {
                    s.updateProvider(Provider.OFFLINE)
                    open = false
                },
            )
            DropdownMenuItem(
                text = { Text("Gemini (облако Google)") },
                leadingIcon = { Icon(Icons.Rounded.Cloud, contentDescription = null) },
                trailingIcon = {
                    if (!offline) Icon(Icons.Rounded.Check, contentDescription = null)
                },
                onClick = {
                    s.updateProvider(Provider.GEMINI)
                    open = false
                },
            )
        }
    }
}

@Composable
private fun EmptyState(
    provider: String,
    hasModel: Boolean,
    hasKey: Boolean,
    onOpenSettings: () -> Unit,
    onSuggestion: (String) -> Unit,
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val minHeight = maxHeight
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .heightIn(min = minHeight)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            BigCookie(size = 112.dp)
            Spacer(Modifier.height(20.dp))
            Text("Привет, я $APP_NAME", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text(
                "Спроси что угодно или отправь фото — я помогу разобраться.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))

            val offline = provider == Provider.OFFLINE
            when {
                offline && !hasModel -> SetupCard(
                    title = "Выбери офлайн-модель",
                    text = "Скачай файл модели (.litertlm) и выбери его в настройках. После этого " +
                        "я буду отвечать прямо на телефоне, без интернета и без ключей.",
                    onOpenSettings = onOpenSettings,
                )
                !offline && !hasKey -> SetupCard(
                    title = "Нужен бесплатный ключ Google AI",
                    text = "Получи его за минуту на aistudio.google.com/apikey и вставь в настройках. " +
                        "Или переключись на офлайн-режим.",
                    onOpenSettings = onOpenSettings,
                )
                else -> {
                    val suggestions = listOf(
                        "Объясни простыми словами, как работает блокчейн",
                        "Составь план тренировок на неделю",
                        "Придумай идею подарка для друга",
                        "Помоги написать вежливое письмо",
                    )
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        suggestions.forEach { text ->
                            AssistChip(
                                onClick = { onSuggestion(text) },
                                label = { Text(text) },
                                shape = RoundedCornerShape(20.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupCard(title: String, text: String, onOpenSettings: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.tertiaryContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Spacer(Modifier.height(14.dp))
            Button(onClick = onOpenSettings) { Text("Открыть настройки") }
        }
    }
}

@Composable
private fun MessageItem(
    message: ChatMessage,
    isLast: Boolean,
    isGenerating: Boolean,
    statusText: String,
    onCopy: () -> Unit,
    onRegenerate: () -> Unit,
) {
    if (message.role == Role.USER) {
        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
            if (message.images.size == 1) {
                MessageImage(message.images.first())
            } else if (message.images.size > 1) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) { message.images.forEach { ImageThumb(it, 112.dp) } }
            }
            if (message.text.isNotBlank()) {
                if (message.images.isNotEmpty()) Spacer(Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp, bottomStart = 24.dp, bottomEnd = 6.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.widthIn(max = 320.dp),
                ) {
                    SelectionContainer {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        )
                    }
                }
            }
        }
    } else {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            AssistantAvatar(size = 32.dp, modifier = Modifier.padding(top = 2.dp))
            Spacer(Modifier.size(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                val waiting = message.text.isBlank() && isGenerating && isLast
                if (waiting) {
                    Column(modifier = Modifier.padding(top = 8.dp)) {
                        WavyIndicator(modifier = Modifier.widthIn(max = 140.dp))
                        if (statusText.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                statusText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                } else if (message.isError) {
                    Surface(
                        shape = RoundedCornerShape(topStart = 6.dp, topEnd = 24.dp, bottomStart = 24.dp, bottomEnd = 24.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                            Icon(
                                Icons.Rounded.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.size(20.dp),
                            )
                            Spacer(Modifier.size(10.dp))
                            Text(
                                message.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                            )
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(topStart = 6.dp, topEnd = 24.dp, bottomStart = 24.dp, bottomEnd = 24.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                    ) {
                        SelectionContainer {
                            MarkdownText(
                                text = message.text,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            )
                        }
                    }
                }
                val streaming = isGenerating && isLast
                if (!waiting && !streaming) {
                    Row(modifier = Modifier.padding(top = 2.dp)) {
                        if (!message.isError) {
                            IconButton(onClick = onCopy, modifier = Modifier.size(40.dp)) {
                                Icon(
                                    Icons.Rounded.ContentCopy,
                                    contentDescription = "Копировать",
                                    modifier = Modifier.size(20.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        if (isLast) {
                            IconButton(onClick = onRegenerate, modifier = Modifier.size(40.dp)) {
                                Icon(
                                    Icons.Rounded.Refresh,
                                    contentDescription = "Ответить заново",
                                    modifier = Modifier.size(20.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InputBar(
    value: String,
    onValueChange: (String) -> Unit,
    pending: List<String>,
    attachBusy: Boolean,
    isGenerating: Boolean,
    onRemoveImage: (String) -> Unit,
    onPickGallery: () -> Unit,
    onPickCamera: () -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    val canSend = (value.isNotBlank() || pending.isNotEmpty()) && !attachBusy

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        if (pending.isNotEmpty() || attachBusy) {
            Row(
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                pending.forEach { path ->
                    Box {
                        ImageThumb(path, 72.dp)
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(4.dp)
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f))
                                .clickable { onRemoveImage(path) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                Icons.Rounded.Close,
                                contentDescription = "Убрать фото",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp),
                            )
                        }
                    }
                }
                if (attachBusy) {
                    Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            Box {
                FilledTonalIconButton(
                    onClick = { menuOpen = true },
                    modifier = Modifier.size(56.dp),
                ) { Icon(Icons.Rounded.Add, contentDescription = "Прикрепить фото") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Сделать фото") },
                        leadingIcon = { Icon(Icons.Rounded.CameraAlt, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onPickCamera()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Выбрать из галереи") },
                        leadingIcon = { Icon(Icons.Rounded.PhotoLibrary, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onPickGallery()
                        },
                    )
                }
            }
            Spacer(Modifier.size(8.dp))
            TextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Сообщение для $APP_NAME") },
                maxLines = 6,
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    disabledContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    errorIndicatorColor = Color.Transparent,
                ),
            )
            Spacer(Modifier.size(8.dp))
            FilledIconButton(
                onClick = { if (isGenerating) onStop() else onSend() },
                enabled = isGenerating || canSend,
                modifier = Modifier.size(56.dp),
                colors = IconButtonDefaults.filledIconButtonColors(),
            ) {
                if (isGenerating) {
                    Icon(Icons.Rounded.Stop, contentDescription = "Остановить")
                } else {
                    Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Отправить")
                }
            }
        }
    }
}
