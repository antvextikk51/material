package com.example.aiagent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.aiagent.ui.AiAgentTheme
import com.example.aiagent.ui.ChatScreen
import com.example.aiagent.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: ChatViewModel = viewModel()
            AiAgentTheme(settings = vm.settings) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
                    var inSettings by rememberSaveable { mutableStateOf(false) }
                    BackHandler(enabled = inSettings) { inSettings = false }
                    AnimatedContent(
                        targetState = inSettings,
                        transitionSpec = {
                            if (targetState) {
                                (slideInHorizontally { it / 4 } + fadeIn()) togetherWith
                                    (slideOutHorizontally { -it / 6 } + fadeOut())
                            } else {
                                (slideInHorizontally { -it / 6 } + fadeIn()) togetherWith
                                    (slideOutHorizontally { it / 4 } + fadeOut())
                            }
                        },
                        label = "screens",
                    ) { settingsOpen ->
                        if (settingsOpen) {
                            SettingsScreen(vm = vm, onBack = { inSettings = false })
                        } else {
                            ChatScreen(vm = vm, onOpenSettings = { inSettings = true })
                        }
                    }
                }
            }
        }
    }
}
