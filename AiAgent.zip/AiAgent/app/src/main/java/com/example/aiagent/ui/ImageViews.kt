package com.example.aiagent.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.aiagent.data.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
private fun rememberFileBitmap(path: String, maxSidePx: Int): ImageBitmap? {
    val bmp by produceState<ImageBitmap?>(initialValue = null, path, maxSidePx) {
        value = withContext(Dispatchers.IO) { ImageUtils.decodeForDisplay(path, maxSidePx)?.asImageBitmap() }
    }
    return bmp
}

/** Квадратная миниатюра (для строки вложений). */
@Composable
fun ImageThumb(path: String, size: Dp, modifier: Modifier = Modifier) {
    val bmp = rememberFileBitmap(path, 300)
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = "Фото",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size),
            )
        }
    }
}

/** Фото внутри сообщения. */
@Composable
fun MessageImage(path: String, modifier: Modifier = Modifier) {
    val bmp = rememberFileBitmap(path, 900)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHighest)
            .sizeIn(minWidth = 96.dp, minHeight = 96.dp, maxWidth = 240.dp, maxHeight = 280.dp)
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = "Фото",
                contentScale = ContentScale.Fit,
                modifier = Modifier.sizeIn(maxWidth = 240.dp, maxHeight = 280.dp),
            )
        }
    }
}
