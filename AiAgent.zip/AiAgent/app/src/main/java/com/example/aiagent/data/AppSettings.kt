package com.example.aiagent.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object ThemeMode {
    const val SYSTEM = "system"
    const val LIGHT = "light"
    const val DARK = "dark"
}

object Palette {
    const val GREY = "grey"
    const val LILAC = "lilac"
    const val DYNAMIC = "dynamic"
}

const val DEFAULT_SYSTEM_PROMPT =
    "Ты дружелюбный и толковый ИИ-ассистент. Отвечай на языке пользователя, " +
        "чётко и по делу. Если пользователь прислал фото, внимательно разбери его."

/** Все настройки приложения. Каждое изменение сразу сохраняется на устройстве. */
class AppSettings(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var themeMode by mutableStateOf(sp.getString("theme_mode", ThemeMode.SYSTEM) ?: ThemeMode.SYSTEM)
        private set
    var palette by mutableStateOf(sp.getString("palette", Palette.GREY) ?: Palette.GREY)
        private set
    var amoled by mutableStateOf(sp.getBoolean("amoled", false))
        private set
    var textScale by mutableFloatStateOf(sp.getFloat("text_scale", 1.0f))
        private set

    var apiKey by mutableStateOf(sp.getString("api_key", "") ?: "")
        private set
    var model by mutableStateOf(sp.getString("model", "gemini-flash-latest") ?: "gemini-flash-latest")
        private set
    var temperature by mutableFloatStateOf(sp.getFloat("temperature", 0.8f))
        private set
    var systemPrompt by mutableStateOf(sp.getString("system_prompt", DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT)
        private set
    var webSearch by mutableStateOf(sp.getBoolean("web_search", false))
        private set

    fun updateThemeMode(v: String) { themeMode = v; sp.edit().putString("theme_mode", v).apply() }
    fun updatePalette(v: String) { palette = v; sp.edit().putString("palette", v).apply() }
    fun updateAmoled(v: Boolean) { amoled = v; sp.edit().putBoolean("amoled", v).apply() }
    fun updateTextScale(v: Float) { textScale = v; sp.edit().putFloat("text_scale", v).apply() }
    fun updateApiKey(v: String) { apiKey = v.trim(); sp.edit().putString("api_key", apiKey).apply() }
    fun updateModel(v: String) { model = v.trim(); sp.edit().putString("model", model).apply() }
    fun updateTemperature(v: Float) { temperature = v; sp.edit().putFloat("temperature", v).apply() }
    fun updateSystemPrompt(v: String) { systemPrompt = v; sp.edit().putString("system_prompt", v).apply() }
    fun updateWebSearch(v: Boolean) { webSearch = v; sp.edit().putBoolean("web_search", v).apply() }

    fun resetAi() {
        updateModel("gemini-flash-latest")
        updateTemperature(0.8f)
        updateSystemPrompt(DEFAULT_SYSTEM_PROMPT)
        updateWebSearch(false)
    }
}
