package com.example.aiagent.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

object ThemeMode {
    const val SYSTEM = "system"
    const val LIGHT = "light"
    const val DARK = "dark"
}

object Palette {
    const val GREY = "grey"
    const val YELLOW = "yellow"
    const val RED = "red"
    const val GREEN = "green"
    const val LILAC = "lilac"
    const val DYNAMIC = "dynamic"
}

/** Откуда берутся ответы: с самого телефона или из облака Google. */
object Provider {
    const val OFFLINE = "offline"
    const val GEMINI = "gemini"
}

const val APP_NAME = "MaterialAgent"

const val DEFAULT_SYSTEM_PROMPT =
    "Тебя зовут MaterialAgent. Ты дружелюбный и толковый ИИ-ассистент. " +
        "Отвечай на языке пользователя, чётко и по делу. " +
        "Если пользователь прислал фото, внимательно разбери его."

/** Все настройки приложения. Каждое изменение сразу сохраняется на устройстве. */
class AppSettings(context: Context) {
    private val appContext = context.applicationContext
    private val sp = appContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    // ---------- Внешний вид ----------
    var themeMode by mutableStateOf(sp.getString("theme_mode", ThemeMode.SYSTEM) ?: ThemeMode.SYSTEM)
        private set
    var palette by mutableStateOf(sp.getString("palette", Palette.GREY) ?: Palette.GREY)
        private set
    var amoled by mutableStateOf(sp.getBoolean("amoled", false))
        private set
    var textScale by mutableFloatStateOf(sp.getFloat("text_scale", 1.0f))
        private set

    // ---------- Источник ответов ----------
    var provider by mutableStateOf(sp.getString("provider", Provider.OFFLINE) ?: Provider.OFFLINE)
        private set

    // ---------- Офлайн-модель ----------
    val localModelFile: File = File(File(appContext.filesDir, "models").apply { mkdirs() }, "model.litertlm")
    var localModelName by mutableStateOf(
        if (localModelFile.exists()) sp.getString("local_model_name", "model.litertlm").orEmpty() else ""
    )
        private set
    var localModelSize by mutableLongStateOf(if (localModelFile.exists()) localModelFile.length() else 0L)
        private set
    var localGpu by mutableStateOf(sp.getBoolean("local_gpu", false))
        private set
    var localVision by mutableStateOf(sp.getBoolean("local_vision", true))
        private set

    val hasLocalModel: Boolean get() = localModelName.isNotEmpty()

    // ---------- Gemini (по желанию) ----------
    var apiKey by mutableStateOf(sp.getString("api_key", "") ?: "")
        private set
    var model by mutableStateOf(sp.getString("model", "gemini-flash-latest") ?: "gemini-flash-latest")
        private set
    var webSearch by mutableStateOf(sp.getBoolean("web_search", false))
        private set

    // ---------- Общее для обоих источников ----------
    var temperature by mutableFloatStateOf(sp.getFloat("temperature", 0.8f))
        private set
    var systemPrompt by mutableStateOf(sp.getString("system_prompt", DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT)
        private set

    fun updateThemeMode(v: String) { themeMode = v; sp.edit().putString("theme_mode", v).apply() }
    fun updatePalette(v: String) { palette = v; sp.edit().putString("palette", v).apply() }
    fun updateAmoled(v: Boolean) { amoled = v; sp.edit().putBoolean("amoled", v).apply() }
    fun updateTextScale(v: Float) { textScale = v; sp.edit().putFloat("text_scale", v).apply() }

    fun updateProvider(v: String) { provider = v; sp.edit().putString("provider", v).apply() }

    fun updateLocalGpu(v: Boolean) { localGpu = v; sp.edit().putBoolean("local_gpu", v).apply() }
    fun updateLocalVision(v: Boolean) { localVision = v; sp.edit().putBoolean("local_vision", v).apply() }
    fun setLocalModel(name: String, size: Long) {
        localModelName = name
        localModelSize = size
        sp.edit().putString("local_model_name", name).apply()
    }
    fun clearLocalModel() {
        localModelName = ""
        localModelSize = 0L
        sp.edit().remove("local_model_name").apply()
    }

    fun updateApiKey(v: String) { apiKey = v.trim(); sp.edit().putString("api_key", apiKey).apply() }
    fun updateModel(v: String) { model = v.trim(); sp.edit().putString("model", model).apply() }
    fun updateWebSearch(v: Boolean) { webSearch = v; sp.edit().putBoolean("web_search", v).apply() }

    fun updateTemperature(v: Float) { temperature = v; sp.edit().putFloat("temperature", v).apply() }
    fun updateSystemPrompt(v: String) { systemPrompt = v; sp.edit().putString("system_prompt", v).apply() }

    fun resetAi() {
        updateModel("gemini-flash-latest")
        updateTemperature(0.8f)
        updateSystemPrompt(DEFAULT_SYSTEM_PROMPT)
        updateWebSearch(false)
        updateLocalGpu(false)
        updateLocalVision(true)
    }
}
