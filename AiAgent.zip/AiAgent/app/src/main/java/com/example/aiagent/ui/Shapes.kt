package com.example.aiagent.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * «Печенька» — фигура с волнистым краем (как в наборе форм Material 3 Expressive).
 * [lobes] — число выступов, [depth] — глубина волны (0..0.2).
 */
class CookieShape(private val lobes: Int = 9, private val depth: Float = 0.07f) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = Path()
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = minOf(cx, cy) / (1f + depth)
        val steps = 240
        for (i in 0..steps) {
            val t = (i.toFloat() / steps) * (2f * PI.toFloat())
            val rr = r * (1f + depth * cos(lobes * t))
            val x = cx + rr * cos(t)
            val y = cy + rr * sin(t)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return Outline.Generic(path)
    }
}

/** Круглый значок ассистента: волнистая «печенька» с искрой внутри. */
@Composable
fun AssistantAvatar(size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CookieShape(lobes = 8, depth = 0.06f))
            .background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Rounded.AutoAwesome,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(size * 0.52f),
        )
    }
}

/** Крупная фигура для пустого экрана. */
@Composable
fun BigCookie(size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CookieShape(lobes = 10, depth = 0.05f))
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Rounded.AutoAwesome,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.size(size * 0.42f),
        )
    }
}

/** Бегущая волнистая линия — индикатор «ассистент думает» (как волнистый прогресс в M3 Expressive). */
@Composable
fun WavyIndicator(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.outlineVariant,
) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "phase",
    )
    Canvas(modifier = modifier.fillMaxWidth().height(16.dp)) {
        val stroke = 4.dp.toPx()
        val amp = 4.dp.toPx()
        val wavelength = 22.dp.toPx()
        val midY = size.height / 2f
        val activeEnd = size.width * 0.6f
        // Дорожка справа
        drawLine(
            color = trackColor,
            start = Offset(activeEnd + stroke, midY),
            end = Offset(size.width - stroke / 2f, midY),
            strokeWidth = stroke,
            cap = StrokeCap.Round,
        )
        // Волна слева
        val path = Path()
        var x = stroke / 2f
        path.moveTo(x, midY + amp * sin(phase - x / wavelength * 2f * PI.toFloat()))
        while (x <= activeEnd) {
            val y = midY + amp * sin(phase - x / wavelength * 2f * PI.toFloat())
            path.lineTo(x, y)
            x += 2f
        }
        drawPath(path, color = color, style = Stroke(width = stroke, cap = StrokeCap.Round))
    }
}

