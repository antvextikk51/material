package com.example.aiagent.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.aiagent.ChatViewModel
import com.example.aiagent.data.APP_NAME
import com.example.aiagent.data.Conversation
import java.util.Calendar

private const val DAY_MS = 86_400_000L

private fun groupLabel(updatedAt: Long, startOfToday: Long): String = when {
    updatedAt >= startOfToday -> "Сегодня"
    updatedAt >= startOfToday - DAY_MS -> "Вчера"
    updatedAt >= startOfToday - 6 * DAY_MS -> "Предыдущие 7 дней"
    else -> "Ранее"
}

private fun startOfToday(): Long {
    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    return cal.timeInMillis
}

/** Боковое меню: новый чат, список чатов по датам, настройки. */
@Composable
fun ChatDrawer(vm: ChatViewModel, onClose: () -> Unit, onOpenSettings: () -> Unit) {
    var renameTarget by remember { mutableStateOf<Conversation?>(null) }
    var deleteTarget by remember { mutableStateOf<Conversation?>(null) }

    val chats = vm.conversations.toList()
    val today = remember(chats.size) { startOfToday() }
    val groups = remember(chats, today) { chats.groupBy { groupLabel(it.updatedAt, today) } }

    ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.padding(start = 28.dp, end = 16.dp, top = 20.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AssistantAvatar(size = 40.dp)
                Spacer(Modifier.size(12.dp))
                Text(APP_NAME, style = MaterialTheme.typography.titleLarge)
            }

            ExtendedFloatingActionButton(
                onClick = {
                    vm.newChat()
                    onClose()
                },
                icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text("Новый чат") },
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .fillMaxWidth(),
            )

            Spacer(Modifier.height(8.dp))

            if (chats.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 28.dp, vertical = 24.dp),
                ) {
                    Text(
                        "Здесь появятся твои чаты. Напиши первое сообщение.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 8.dp),
                ) {
                    groups.forEach { (label, list) ->
                        item(key = "header_$label") {
                            Text(
                                label,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(start = 28.dp, end = 16.dp, top = 12.dp, bottom = 6.dp),
                            )
                        }
                        items(list, key = { it.id }) { chat ->
                            ChatRow(
                                chat = chat,
                                selected = chat.id == vm.currentId,
                                onClick = {
                                    vm.openChat(chat.id)
                                    onClose()
                                },
                                onRename = { renameTarget = chat },
                                onDelete = { deleteTarget = chat },
                            )
                        }
                    }
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 28.dp),
                color = MaterialTheme.colorScheme.outlineVariant,
            )
            NavigationDrawerItem(
                label = { Text("Настройки") },
                icon = { Icon(Icons.Rounded.Settings, contentDescription = null) },
                selected = false,
                onClick = {
                    onClose()
                    onOpenSettings()
                },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            )
        }
    }

    renameTarget?.let { target ->
        var text by remember(target.id) { mutableStateOf(target.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Переименовать чат") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    label = { Text("Название") },
                )
            },
            confirmButton = {
                TextButton(
                    enabled = text.isNotBlank(),
                    onClick = {
                        vm.renameChat(target.id, text)
                        renameTarget = null
                    },
                ) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Отмена") } },
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Удалить чат?") },
            text = { Text("«${target.title}» и все фото из него будут удалены без возможности восстановления.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteChat(target.id)
                    deleteTarget = null
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun ChatRow(
    chat: Conversation,
    selected: Boolean,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    NavigationDrawerItem(
        label = { Text(chat.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        icon = { Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = null) },
        selected = selected,
        onClick = onClick,
        badge = {
            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Rounded.MoreVert,
                        contentDescription = "Действия с чатом",
                        modifier = Modifier.size(20.dp),
                    )
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Переименовать") },
                        leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onRename()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Удалить") },
                        leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            onDelete()
                        },
                    )
                }
            }
        },
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
    )
}
