package com.example.aiagent.ui

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import com.example.aiagent.data.AppSettings
import com.example.aiagent.data.Palette
import com.example.aiagent.data.ThemeMode

// ---------- Серая палитра (по умолчанию): мягкий нейтральный серый, без резких контрастов ----------

private val GreyLight = lightColorScheme(
    primary = Color(0xFF565C66),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDDE1E8),
    onPrimaryContainer = Color(0xFF161A20),
    inversePrimary = Color(0xFFC3C7CF),
    secondary = Color(0xFF5E6269),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE3E5EB),
    onSecondaryContainer = Color(0xFF1B1E23),
    tertiary = Color(0xFF6C5F6E),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFEEE0EE),
    onTertiaryContainer = Color(0xFF261A28),
    background = Color(0xFFF8F9FB),
    onBackground = Color(0xFF1A1C1E),
    surface = Color(0xFFF8F9FB),
    onSurface = Color(0xFF1A1C1E),
    surfaceVariant = Color(0xFFDFE2E8),
    onSurfaceVariant = Color(0xFF43474E),
    surfaceTint = Color(0xFF565C66),
    inverseSurface = Color(0xFF2F3033),
    inverseOnSurface = Color(0xFFF1F0F4),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    outline = Color(0xFF73777F),
    outlineVariant = Color(0xFFC3C6CF),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFFF8F9FB),
    surfaceDim = Color(0xFFD9DADD),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF2F3F6),
    surfaceContainer = Color(0xFFECEEF1),
    surfaceContainerHigh = Color(0xFFE6E8EB),
    surfaceContainerHighest = Color(0xFFE0E2E6),
)

private val GreyDark = darkColorScheme(
    primary = Color(0xFFC3C7CF),
    onPrimary = Color(0xFF2C3037),
    primaryContainer = Color(0xFF434850),
    onPrimaryContainer = Color(0xFFDFE3EA),
    inversePrimary = Color(0xFF565C66),
    secondary = Color(0xFFC7C9D0),
    onSecondary = Color(0xFF2D3036),
    secondaryContainer = Color(0xFF43464D),
    onSecondaryContainer = Color(0xFFE3E5EB),
    tertiary = Color(0xFFD6C3D5),
    onTertiary = Color(0xFF3B2D3C),
    tertiaryContainer = Color(0xFF524353),
    onTertiaryContainer = Color(0xFFF3DFF2),
    background = Color(0xFF121315),
    onBackground = Color(0xFFE3E2E6),
    surface = Color(0xFF121315),
    onSurface = Color(0xFFE3E2E6),
    surfaceVariant = Color(0xFF43474E),
    onSurfaceVariant = Color(0xFFC3C6CF),
    surfaceTint = Color(0xFFC3C7CF),
    inverseSurface = Color(0xFFE3E2E6),
    inverseOnSurface = Color(0xFF2F3033),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    outline = Color(0xFF8D9199),
    outlineVariant = Color(0xFF43474E),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFF38393C),
    surfaceDim = Color(0xFF121315),
    surfaceContainerLowest = Color(0xFF0D0E10),
    surfaceContainerLow = Color(0xFF1A1B1E),
    surfaceContainer = Color(0xFF1E1F22),
    surfaceContainerHigh = Color(0xFF292A2D),
    surfaceContainerHighest = Color(0xFF343538),
)

// ---------- Сиреневая палитра (как на скриншоте-образце) ----------

private val LilacLight = lightColorScheme(
    primary = Color(0xFF7D4A99),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFF0D6FF),
    onPrimaryContainer = Color(0xFF2F0A4A),
    inversePrimary = Color(0xFFE3B5FF),
    secondary = Color(0xFF6B586F),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF3DCF6),
    onSecondaryContainer = Color(0xFF251429),
    tertiary = Color(0xFF8A4D5B),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFD9DF),
    onTertiaryContainer = Color(0xFF3A0B19),
    background = Color(0xFFFFF7FC),
    onBackground = Color(0xFF1E1A20),
    surface = Color(0xFFFFF7FC),
    onSurface = Color(0xFF1E1A20),
    surfaceVariant = Color(0xFFEBDFEC),
    onSurfaceVariant = Color(0xFF4C444D),
    surfaceTint = Color(0xFF7D4A99),
    inverseSurface = Color(0xFF332F35),
    inverseOnSurface = Color(0xFFF8EEF8),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    outline = Color(0xFF7E747F),
    outlineVariant = Color(0xFFCFC3D0),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFFFFF7FC),
    surfaceDim = Color(0xFFE2D8E2),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFBF0FA),
    surfaceContainer = Color(0xFFF6EAF6),
    surfaceContainerHigh = Color(0xFFF0E4F1),
    surfaceContainerHighest = Color(0xFFEBDEEB),
)

private val LilacDark = darkColorScheme(
    primary = Color(0xFFE3B5FF),
    onPrimary = Color(0xFF4A1A66),
    primaryContainer = Color(0xFF63327F),
    onPrimaryContainer = Color(0xFFF2DAFF),
    inversePrimary = Color(0xFF7D4A99),
    secondary = Color(0xFFD8BFDC),
    onSecondary = Color(0xFF3B2A3F),
    secondaryContainer = Color(0xFF534157),
    onSecondaryContainer = Color(0xFFF3DCF6),
    tertiary = Color(0xFFF2B7C4),
    onTertiary = Color(0xFF512533),
    tertiaryContainer = Color(0xFF6D3A48),
    onTertiaryContainer = Color(0xFFFFD9DF),
    background = Color(0xFF161217),
    onBackground = Color(0xFFE9DFE9),
    surface = Color(0xFF161217),
    onSurface = Color(0xFFE9DFE9),
    surfaceVariant = Color(0xFF4C444D),
    onSurfaceVariant = Color(0xFFCFC3D0),
    surfaceTint = Color(0xFFE3B5FF),
    inverseSurface = Color(0xFFE9DFE9),
    inverseOnSurface = Color(0xFF332F35),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    outline = Color(0xFF988E99),
    outlineVariant = Color(0xFF4C444D),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFF3D373E),
    surfaceDim = Color(0xFF161217),
    surfaceContainerLowest = Color(0xFF110D12),
    surfaceContainerLow = Color(0xFF1E1A20),
    surfaceContainer = Color(0xFF231E24),
    surfaceContainerHigh = Color(0xFF2D282F),
    surfaceContainerHighest = Color(0xFF38333A),
)


// ---------- Палитры, построенные по одному оттенку: мягкая жёлтая, красная и зелёная ----------

private class Seed(val hue: Double, val chroma: Double, val neutral: Double, val tertiaryShift: Double)

private val YellowSeed = Seed(hue = 98.0, chroma = 0.075, neutral = 0.012, tertiaryShift = 60.0)
private val RedSeed = Seed(hue = 18.0, chroma = 0.095, neutral = 0.012, tertiaryShift = 50.0)
private val GreenSeed = Seed(hue = 150.0, chroma = 0.080, neutral = 0.012, tertiaryShift = 80.0)

/** Яркость «тона» Material (0..100) в шкале OKLab. */
private fun toneToLightness(tone: Double): Double {
    val y = if (tone > 8.0) ((tone + 16.0) / 116.0).pow(3.0) else tone / 903.3
    return y.pow(1.0 / 3.0)
}

private fun linearToSrgb(x: Double): Double =
    if (x <= 0.0031308) 12.92 * x else 1.055 * x.pow(1.0 / 2.4) - 0.055

private fun oklchToLinear(lightness: Double, chroma: Double, hueDeg: Double): DoubleArray {
    val h = Math.toRadians(hueDeg)
    val a = chroma * cos(h)
    val b = chroma * sin(h)
    val l1 = lightness + 0.3963377774 * a + 0.2158037573 * b
    val m1 = lightness - 0.1055613458 * a - 0.0638541728 * b
    val s1 = lightness - 0.0894841775 * a - 1.2914855480 * b
    val l = l1 * l1 * l1
    val m = m1 * m1 * m1
    val s = s1 * s1 * s1
    return doubleArrayOf(
        4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
        -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
        -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s,
    )
}

/** Цвет нужного тона и оттенка; если цвет не помещается в sRGB, насыщенность снижается. */
private fun tonal(tone: Double, chroma: Double, hue: Double): Color {
    val lightness = toneToLightness(tone)
    var c = chroma
    for (i in 0 until 40) {
        val rgb = oklchToLinear(lightness, c, hue)
        if (rgb.all { it >= -0.0005 && it <= 1.0005 }) break
        c *= 0.93
    }
    val rgb = oklchToLinear(lightness, c, hue)
    fun channel(v: Double): Float = linearToSrgb(v.coerceIn(0.0, 1.0)).coerceIn(0.0, 1.0).toFloat()
    return Color(channel(rgb[0]), channel(rgb[1]), channel(rgb[2]))
}

private fun generatedScheme(seed: Seed, dark: Boolean): ColorScheme {
    val h = seed.hue
    fun p(t: Double) = tonal(t, seed.chroma, h)
    fun s(t: Double) = tonal(t, seed.chroma * 0.4, h + 8.0)
    fun te(t: Double) = tonal(t, seed.chroma * 0.75, h + seed.tertiaryShift)
    fun n(t: Double) = tonal(t, seed.neutral, h)
    fun nv(t: Double) = tonal(t, seed.neutral * 2.0, h)
    return if (!dark) {
        lightColorScheme(
            primary = p(40.0), onPrimary = p(100.0),
            primaryContainer = p(90.0), onPrimaryContainer = p(10.0),
            inversePrimary = p(80.0),
            secondary = s(40.0), onSecondary = s(100.0),
            secondaryContainer = s(90.0), onSecondaryContainer = s(10.0),
            tertiary = te(40.0), onTertiary = te(100.0),
            tertiaryContainer = te(90.0), onTertiaryContainer = te(10.0),
            background = n(98.0), onBackground = n(10.0),
            surface = n(98.0), onSurface = n(10.0),
            surfaceVariant = nv(90.0), onSurfaceVariant = nv(30.0),
            surfaceTint = p(40.0),
            inverseSurface = n(20.0), inverseOnSurface = n(95.0),
            error = Color(0xFFBA1A1A), onError = Color(0xFFFFFFFF),
            errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
            outline = nv(50.0), outlineVariant = nv(80.0),
            scrim = Color(0xFF000000),
            surfaceBright = n(98.0), surfaceDim = n(87.0),
            surfaceContainerLowest = n(100.0), surfaceContainerLow = n(96.0),
            surfaceContainer = n(94.0), surfaceContainerHigh = n(92.0),
            surfaceContainerHighest = n(90.0),
        )
    } else {
        darkColorScheme(
            primary = p(80.0), onPrimary = p(20.0),
            primaryContainer = p(30.0), onPrimaryContainer = p(90.0),
            inversePrimary = p(40.0),
            secondary = s(80.0), onSecondary = s(20.0),
            secondaryContainer = s(30.0), onSecondaryContainer = s(90.0),
            tertiary = te(80.0), onTertiary = te(20.0),
            tertiaryContainer = te(30.0), onTertiaryContainer = te(90.0),
            background = n(6.0), onBackground = n(90.0),
            surface = n(6.0), onSurface = n(90.0),
            surfaceVariant = nv(30.0), onSurfaceVariant = nv(80.0),
            surfaceTint = p(80.0),
            inverseSurface = n(90.0), inverseOnSurface = n(20.0),
            error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
            errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
            outline = nv(60.0), outlineVariant = nv(30.0),
            scrim = Color(0xFF000000),
            surfaceBright = n(24.0), surfaceDim = n(6.0),
            surfaceContainerLowest = n(4.0), surfaceContainerLow = n(10.0),
            surfaceContainer = n(12.0), surfaceContainerHigh = n(17.0),
            surfaceContainerHighest = n(22.0),
        )
    }
}

/** Цветовая схема выбранной палитры (кроме «Из обоев», она зависит от телефона). */
fun paletteScheme(palette: String, dark: Boolean): ColorScheme = when (palette) {
    Palette.YELLOW -> generatedScheme(YellowSeed, dark)
    Palette.RED -> generatedScheme(RedSeed, dark)
    Palette.GREEN -> generatedScheme(GreenSeed, dark)
    Palette.LILAC -> if (dark) LilacDark else LilacLight
    else -> if (dark) GreyDark else GreyLight
}

private fun ColorScheme.toAmoled(): ColorScheme = copy(
    background = Color.Black,
    surface = Color.Black,
    surfaceDim = Color.Black,
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color(0xFF0C0C0D),
    surfaceContainer = Color(0xFF141416),
    surfaceContainerHigh = Color(0xFF1C1C1F),
    surfaceContainerHighest = Color(0xFF252528),
)

/** Скругления в духе Material 3 Expressive: крупные, мягкие формы. */
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp),
)

@Composable
fun AiAgentTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        else -> isSystemInDarkTheme()
    }
    val context = LocalContext.current
    val dynamicOk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    var scheme = if (settings.palette == Palette.DYNAMIC && dynamicOk) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        remember(settings.palette, dark) { paletteScheme(settings.palette, dark) }
    }
    if (dark && settings.amoled) scheme = scheme.toAmoled()

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    val base = LocalDensity.current
    val scaledDensity = Density(base.density, base.fontScale * settings.textScale)

    MaterialTheme(colorScheme = scheme, shapes = AppShapes) {
        CompositionLocalProvider(LocalDensity provides scaledDensity) {
            content()
        }
    }
}
