package com.example.aiagent.ui

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import com.example.aiagent.data.AppSettings
import com.example.aiagent.data.Palette
import com.example.aiagent.data.ThemeMode

// ---------- Серая палитра (по умолчанию): мягкий нейтральный серый, без резких контрастов ----------

private val GreyLight = lightColorScheme(
    primary = Color(0xFF565C66),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDDE1E8),
    onPrimaryContainer = Color(0xFF161A20),
    inversePrimary = Color(0xFFC3C7CF),
    secondary = Color(0xFF5E6269),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE3E5EB),
    onSecondaryContainer = Color(0xFF1B1E23),
    tertiary = Color(0xFF6C5F6E),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFEEE0EE),
    onTertiaryContainer = Color(0xFF261A28),
    background = Color(0xFFF8F9FB),
    onBackground = Color(0xFF1A1C1E),
    surface = Color(0xFFF8F9FB),
    onSurface = Color(0xFF1A1C1E),
    surfaceVariant = Color(0xFFDFE2E8),
    onSurfaceVariant = Color(0xFF43474E),
    surfaceTint = Color(0xFF565C66),
    inverseSurface = Color(0xFF2F3033),
    inverseOnSurface = Color(0xFFF1F0F4),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    outline = Color(0xFF73777F),
    outlineVariant = Color(0xFFC3C6CF),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFFF8F9FB),
    surfaceDim = Color(0xFFD9DADD),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF2F3F6),
    surfaceContainer = Color(0xFFECEEF1),
    surfaceContainerHigh = Color(0xFFE6E8EB),
    surfaceContainerHighest = Color(0xFFE0E2E6),
)

private val GreyDark = darkColorScheme(
    primary = Color(0xFFC3C7CF),
    onPrimary = Color(0xFF2C3037),
    primaryContainer = Color(0xFF434850),
    onPrimaryContainer = Color(0xFFDFE3EA),
    inversePrimary = Color(0xFF565C66),
    secondary = Color(0xFFC7C9D0),
    onSecondary = Color(0xFF2D3036),
    secondaryContainer = Color(0xFF43464D),
    onSecondaryContainer = Color(0xFFE3E5EB),
    tertiary = Color(0xFFD6C3D5),
    onTertiary = Color(0xFF3B2D3C),
    tertiaryContainer = Color(0xFF524353),
    onTertiaryContainer = Color(0xFFF3DFF2),
    background = Color(0xFF121315),
    onBackground = Color(0xFFE3E2E6),
    surface = Color(0xFF121315),
    onSurface = Color(0xFFE3E2E6),
    surfaceVariant = Color(0xFF43474E),
    onSurfaceVariant = Color(0xFFC3C6CF),
    surfaceTint = Color(0xFFC3C7CF),
    inverseSurface = Color(0xFFE3E2E6),
    inverseOnSurface = Color(0xFF2F3033),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    outline = Color(0xFF8D9199),
    outlineVariant = Color(0xFF43474E),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFF38393C),
    surfaceDim = Color(0xFF121315),
    surfaceContainerLowest = Color(0xFF0D0E10),
    surfaceContainerLow = Color(0xFF1A1B1E),
    surfaceContainer = Color(0xFF1E1F22),
    surfaceContainerHigh = Color(0xFF292A2D),
    surfaceContainerHighest = Color(0xFF343538),
)

// ---------- Сиреневая палитра (как на скриншоте-образце) ----------

private val LilacLight = lightColorScheme(
    primary = Color(0xFF7D4A99),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFF0D6FF),
    onPrimaryContainer = Color(0xFF2F0A4A),
    inversePrimary = Color(0xFFE3B5FF),
    secondary = Color(0xFF6B586F),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF3DCF6),
    onSecondaryContainer = Color(0xFF251429),
    tertiary = Color(0xFF8A4D5B),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFD9DF),
    onTertiaryContainer = Color(0xFF3A0B19),
    background = Color(0xFFFFF7FC),
    onBackground = Color(0xFF1E1A20),
    surface = Color(0xFFFFF7FC),
    onSurface = Color(0xFF1E1A20),
    surfaceVariant = Color(0xFFEBDFEC),
    onSurfaceVariant = Color(0xFF4C444D),
    surfaceTint = Color(0xFF7D4A99),
    inverseSurface = Color(0xFF332F35),
    inverseOnSurface = Color(0xFFF8EEF8),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    outline = Color(0xFF7E747F),
    outlineVariant = Color(0xFFCFC3D0),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFFFFF7FC),
    surfaceDim = Color(0xFFE2D8E2),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFBF0FA),
    surfaceContainer = Color(0xFFF6EAF6),
    surfaceContainerHigh = Color(0xFFF0E4F1),
    surfaceContainerHighest = Color(0xFFEBDEEB),
)

private val LilacDark = darkColorScheme(
    primary = Color(0xFFE3B5FF),
    onPrimary = Color(0xFF4A1A66),
    primaryContainer = Color(0xFF63327F),
    onPrimaryContainer = Color(0xFFF2DAFF),
    inversePrimary = Color(0xFF7D4A99),
    secondary = Color(0xFFD8BFDC),
    onSecondary = Color(0xFF3B2A3F),
    secondaryContainer = Color(0xFF534157),
    onSecondaryContainer = Color(0xFFF3DCF6),
    tertiary = Color(0xFFF2B7C4),
    onTertiary = Color(0xFF512533),
    tertiaryContainer = Color(0xFF6D3A48),
    onTertiaryContainer = Color(0xFFFFD9DF),
    background = Color(0xFF161217),
    onBackground = Color(0xFFE9DFE9),
    surface = Color(0xFF161217),
    onSurface = Color(0xFFE9DFE9),
    surfaceVariant = Color(0xFF4C444D),
    onSurfaceVariant = Color(0xFFCFC3D0),
    surfaceTint = Color(0xFFE3B5FF),
    inverseSurface = Color(0xFFE9DFE9),
    inverseOnSurface = Color(0xFF332F35),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    outline = Color(0xFF988E99),
    outlineVariant = Color(0xFF4C444D),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFF3D373E),
    surfaceDim = Color(0xFF161217),
    surfaceContainerLowest = Color(0xFF110D12),
    surfaceContainerLow = Color(0xFF1E1A20),
    surfaceContainer = Color(0xFF231E24),
    surfaceContainerHigh = Color(0xFF2D282F),
    surfaceContainerHighest = Color(0xFF38333A),
)

private fun ColorScheme.toAmoled(): ColorScheme = copy(
    background = Color.Black,
    surface = Color.Black,
    surfaceDim = Color.Black,
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color(0xFF0C0C0D),
    surfaceContainer = Color(0xFF141416),
    surfaceContainerHigh = Color(0xFF1C1C1F),
    surfaceContainerHighest = Color(0xFF252528),
)

/** Скругления в духе Material 3 Expressive: крупные, мягкие формы. */
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp),
)

@Composable
fun AiAgentTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        else -> isSystemInDarkTheme()
    }
    val context = LocalContext.current
    val dynamicOk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    var scheme = when {
        settings.palette == Palette.DYNAMIC && dynamicOk ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        settings.palette == Palette.LILAC -> if (dark) LilacDark else LilacLight
        else -> if (dark) GreyDark else GreyLight
    }
    if (dark && settings.amoled) scheme = scheme.toAmoled()

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    val base = LocalDensity.current
    val scaledDensity = Density(base.density, base.fontScale * settings.textScale)

    MaterialTheme(colorScheme = scheme, shapes = AppShapes) {
        CompositionLocalProvider(LocalDensity provides scaledDensity) {
            content()
        }
    }
}
