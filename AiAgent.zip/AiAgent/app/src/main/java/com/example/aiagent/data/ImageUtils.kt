package com.example.aiagent.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

object ImageUtils {
    private const val MAX_SIDE = 1600

    private fun imagesDir(context: Context): File =
        File(context.applicationContext.filesDir, "images").apply { mkdirs() }

    /**
     * Читает фото по Uri (галерея/камера), учитывает поворот из EXIF,
     * уменьшает до разумного размера и сохраняет JPEG во внутреннюю память.
     * Возвращает путь к файлу или null при ошибке.
     */
    fun saveFromUri(context: Context, uri: Uri): String? {
        return try {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            val bitmap = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val longest = max(w, h)
                if (longest > MAX_SIDE) {
                    val scale = MAX_SIDE.toFloat() / longest
                    decoder.setTargetSize(
                        (w * scale).toInt().coerceAtLeast(1),
                        (h * scale).toInt().coerceAtLeast(1),
                    )
                }
            }
            val out = File(imagesDir(context), "img_${System.nanoTime()}.jpg")
            FileOutputStream(out).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            bitmap.recycle()
            out.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    /** Декодирует файл для показа в интерфейсе в уменьшенном виде. */
    fun decodeForDisplay(path: String, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(path, opts)
        } catch (e: Exception) {
            null
        }
    }

    fun readBytes(path: String): ByteArray? = try {
        File(path).readBytes()
    } catch (e: Exception) {
        null
    }

    fun deleteFiles(paths: Collection<String>) {
        paths.forEach { runCatching { File(it).delete() } }
    }

    fun deleteAll(context: Context) {
        imagesDir(context).listFiles()?.forEach { runCatching { it.delete() } }
    }
}
