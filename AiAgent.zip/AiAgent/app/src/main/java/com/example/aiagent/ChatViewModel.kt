package com.example.aiagent

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.aiagent.data.AppSettings
import com.example.aiagent.data.ChatMessage
import com.example.aiagent.data.ChatStore
import com.example.aiagent.data.GeminiClient
import com.example.aiagent.data.GeminiException
import com.example.aiagent.data.ImageUtils
import com.example.aiagent.data.Role
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    val settings = AppSettings(app)
    private val store = ChatStore(app)

    val messages = mutableStateListOf<ChatMessage>()

    /** Фото, прикреплённые к ещё не отправленному сообщению. */
    val pendingImages = mutableStateListOf<String>()

    var isGenerating by mutableStateOf(false)
        private set
    var attachBusy by mutableStateOf(false)
        private set
    /** Одноразовое сообщение для Snackbar. */
    var notice by mutableStateOf<String?>(null)

    private var job: Job? = null
    private var idCounter = System.currentTimeMillis()

    init {
        messages.addAll(store.load())
    }

    private fun nextId(): Long = ++idCounter

    fun attachFromUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            attachBusy = true
            var failed = 0
            for (uri in uris) {
                if (pendingImages.size >= MAX_IMAGES) {
                    notice = "Можно прикрепить не больше $MAX_IMAGES фото"
                    break
                }
                val path = withContext(Dispatchers.IO) { ImageUtils.saveFromUri(getApplication(), uri) }
                if (path != null) pendingImages.add(path) else failed++
            }
            if (failed > 0) notice = "Не удалось загрузить фото"
            attachBusy = false
        }
    }

    fun removePending(path: String) {
        if (pendingImages.remove(path)) ImageUtils.deleteFiles(listOf(path))
    }

    fun send(text: String) {
        val trimmed = text.trim()
        if (isGenerating || attachBusy) return
        if (trimmed.isEmpty() && pendingImages.isEmpty()) return
        if (settings.apiKey.isBlank()) {
            notice = "Сначала добавь API-ключ в настройках"
            return
        }
        val imgs = pendingImages.toList()
        pendingImages.clear()
        messages.add(ChatMessage(nextId(), Role.USER, trimmed, imgs))
        store.save(messages)
        generate()
    }

    fun regenerate() {
        if (isGenerating) return
        // Убираем последний ответ модели (в том числе ошибку) и просим ответить заново.
        while (messages.isNotEmpty() && messages.last().role == Role.MODEL) {
            messages.removeAt(messages.lastIndex)
        }
        if (messages.isEmpty() || messages.last().role != Role.USER) return
        store.save(messages)
        generate()
    }

    fun stop() {
        job?.cancel()
    }

    private fun generate() {
        val history = messages.toList()
        val answerId = nextId()
        messages.add(ChatMessage(answerId, Role.MODEL, ""))
        isGenerating = true

        job = viewModelScope.launch {
            val sb = StringBuilder()
            var lastUpdate = 0L
            try {
                GeminiClient.streamChat(
                    apiKey = settings.apiKey,
                    model = settings.model,
                    systemPrompt = settings.systemPrompt,
                    temperature = settings.temperature,
                    webSearch = settings.webSearch,
                    history = history,
                ) { delta ->
                    sb.append(delta)
                    val now = System.currentTimeMillis()
                    if (now - lastUpdate > 40) {
                        lastUpdate = now
                        // onDelta вызывается из IO-потока: берём снимок текста и обновляем состояние на главном потоке.
                        val snapshot = sb.toString()
                        viewModelScope.launch(Dispatchers.Main.immediate) {
                            replaceAnswer(answerId, snapshot, false)
                        }
                    }
                }
                replaceAnswer(answerId, sb.toString(), false)
            } catch (e: CancellationException) {
                if (sb.isBlank()) removeAnswer(answerId) else replaceAnswer(answerId, sb.toString(), false)
            } catch (e: GeminiException) {
                if (sb.isBlank()) replaceAnswer(answerId, e.message ?: "Ошибка", true)
                else {
                    replaceAnswer(answerId, sb.toString(), false)
                    notice = e.message
                }
            } catch (e: Exception) {
                replaceAnswer(answerId, "Что-то пошло не так: ${e.message ?: e.javaClass.simpleName}", true)
            } finally {
                isGenerating = false
                store.save(messages)
            }
        }
    }

    private fun replaceAnswer(id: Long, text: String, isError: Boolean) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text, isError = isError)
    }

    private fun removeAnswer(id: Long) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) messages.removeAt(i)
    }

    fun clearChat() {
        job?.cancel()
        messages.clear()
        pendingImages.clear()
        ImageUtils.deleteAll(getApplication())
        store.save(messages)
    }

    companion object {
        const val MAX_IMAGES = 4
    }
}
