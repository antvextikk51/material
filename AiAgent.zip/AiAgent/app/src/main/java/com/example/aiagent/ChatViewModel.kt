package com.example.aiagent

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.aiagent.data.AppSettings
import com.example.aiagent.data.ChatMessage
import com.example.aiagent.data.ChatStore
import com.example.aiagent.data.Conversation
import com.example.aiagent.data.GeminiClient
import com.example.aiagent.data.GeminiException
import com.example.aiagent.data.ImageUtils
import com.example.aiagent.data.LocalLlm
import com.example.aiagent.data.LocalLlmException
import com.example.aiagent.data.Provider
import com.example.aiagent.data.Role
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    val settings = AppSettings(app)
    private val store = ChatStore(app)

    /** Список чатов для бокового меню (свежие сверху). */
    val conversations = mutableStateListOf<Conversation>()

    /** Открытый чат. null — новый чат, который ещё не отправил ни одного сообщения. */
    var currentId by mutableStateOf<Long?>(null)
        private set

    val messages = mutableStateListOf<ChatMessage>()

    /** Фото, прикреплённые к ещё не отправленному сообщению. */
    val pendingImages = mutableStateListOf<String>()

    var isGenerating by mutableStateOf(false)
        private set
    var attachBusy by mutableStateOf(false)
        private set

    /** Пояснение, пока ИИ ещё не начал отвечать (например, «Загружаю модель…»). */
    var statusText by mutableStateOf("")
        private set

    /** Прогресс копирования модели 0..1. null — копирование не идёт. */
    var importProgress by mutableStateOf<Float?>(null)
        private set

    /** Одноразовое сообщение для Snackbar. */
    var notice by mutableStateOf<String?>(null)

    private var job: Job? = null
    private var importJob: Job? = null
    private var idCounter = System.currentTimeMillis()

    val currentTitle: String
        get() = conversations.firstOrNull { it.id == currentId }?.title ?: ""

    init {
        conversations.addAll(store.loadIndex())
        // Открываем последний чат, как в привычных мессенджерах.
        conversations.firstOrNull()?.let { openChat(it.id) }
    }

    private fun nextId(): Long = ++idCounter

    // ------------------------------------------------------------------
    // Чаты
    // ------------------------------------------------------------------

    fun newChat() {
        stopInternal()
        saveCurrent()
        currentId = null
        messages.clear()
        discardPending()
    }

    fun openChat(id: Long) {
        if (id == currentId) return
        stopInternal()
        saveCurrent()
        discardPending()
        currentId = id
        messages.clear()
        messages.addAll(store.loadMessages(id))
    }

    fun renameChat(id: Long, title: String) {
        val clean = title.trim().take(60)
        if (clean.isEmpty()) return
        val i = conversations.indexOfFirst { it.id == id }
        if (i < 0) return
        conversations[i] = conversations[i].copy(title = clean)
        store.saveIndex(conversations.toList())
    }

    fun deleteChat(id: Long) {
        if (id == currentId) {
            stopInternal()
            currentId = null
            messages.clear()
            discardPending()
        }
        conversations.removeAll { it.id == id }
        store.deleteChat(id)
        store.saveIndex(conversations.toList())
    }

    fun deleteAllChats() {
        stopInternal()
        conversations.toList().forEach { store.deleteChat(it.id) }
        conversations.clear()
        currentId = null
        messages.clear()
        discardPending()
        ImageUtils.deleteAll(getApplication())
        store.saveIndex(emptyList())
    }

    private fun saveCurrent() {
        val id = currentId ?: return
        store.saveMessages(id, messages.toList())
    }

    /** Создаёт запись о чате при первой отправке и поднимает чат наверх списка. */
    private fun touchConversation(firstText: String, hasImages: Boolean) {
        val now = System.currentTimeMillis()
        var id = currentId
        if (id == null) {
            id = nextId()
            currentId = id
            val title = firstText.trim().lineSequence().firstOrNull().orEmpty().take(40)
                .ifBlank { if (hasImages) "Фото" else "Новый чат" }
            conversations.add(0, Conversation(id, title, now))
        } else {
            val i = conversations.indexOfFirst { it.id == id }
            if (i >= 0) {
                val updated = conversations[i].copy(updatedAt = now)
                conversations.removeAt(i)
                conversations.add(0, updated)
            }
        }
        store.saveIndex(conversations.toList())
    }

    // ------------------------------------------------------------------
    // Фото
    // ------------------------------------------------------------------

    fun attachFromUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            attachBusy = true
            var failed = 0
            for (uri in uris) {
                if (pendingImages.size >= MAX_IMAGES) {
                    notice = "Можно прикрепить не больше $MAX_IMAGES фото"
                    break
                }
                val path = withContext(Dispatchers.IO) { ImageUtils.saveFromUri(getApplication(), uri) }
                if (path != null) pendingImages.add(path) else failed++
            }
            if (failed > 0) notice = "Не удалось загрузить фото"
            attachBusy = false
        }
    }

    fun removePending(path: String) {
        if (pendingImages.remove(path)) ImageUtils.deleteFiles(listOf(path))
    }

    private fun discardPending() {
        ImageUtils.deleteFiles(pendingImages.toList())
        pendingImages.clear()
    }

    // ------------------------------------------------------------------
    // Отправка и ответы
    // ------------------------------------------------------------------

    /** Проверяет, что выбранный источник готов отвечать. Возвращает false и показывает подсказку, если нет. */
    private fun sourceReady(): Boolean {
        if (settings.provider == Provider.OFFLINE) {
            if (!settings.hasLocalModel) {
                notice = "Сначала выбери офлайн-модель в настройках или переключись на Gemini"
                return false
            }
        } else if (settings.apiKey.isBlank()) {
            notice = "Сначала добавь API-ключ Gemini в настройках"
            return false
        }
        return true
    }

    fun send(text: String) {
        val trimmed = text.trim()
        if (isGenerating || attachBusy) return
        if (trimmed.isEmpty() && pendingImages.isEmpty()) return
        if (!sourceReady()) return
        val imgs = pendingImages.toList()
        pendingImages.clear()
        touchConversation(trimmed, imgs.isNotEmpty())
        messages.add(ChatMessage(nextId(), Role.USER, trimmed, imgs))
        saveCurrent()
        generate()
    }

    fun regenerate() {
        if (isGenerating) return
        if (!sourceReady()) return
        // Убираем последний ответ модели (в том числе ошибку) и просим ответить заново.
        while (messages.isNotEmpty() && messages.last().role == Role.MODEL) {
            messages.removeAt(messages.lastIndex)
        }
        if (messages.isEmpty() || messages.last().role != Role.USER) return
        saveCurrent()
        generate()
    }

    fun stop() {
        job?.cancel()
    }

    private fun stopInternal() {
        job?.cancel()
        job = null
        isGenerating = false
        statusText = ""
    }

    private fun generate() {
        val history = messages.toList()
        val answerId = nextId()
        val chatId = currentId
        messages.add(ChatMessage(answerId, Role.MODEL, ""))
        isGenerating = true
        statusText = ""

        val offline = settings.provider == Provider.OFFLINE

        job = viewModelScope.launch {
            val sb = StringBuilder()
            var lastUpdate = 0L
            // Вызывается из рабочего потока: снимок текста и обновление состояния на главном потоке.
            val onDelta: (String) -> Unit = { delta ->
                sb.append(delta)
                val now = System.currentTimeMillis()
                if (now - lastUpdate > 40) {
                    lastUpdate = now
                    val snapshot = sb.toString()
                    viewModelScope.launch(Dispatchers.Main.immediate) {
                        if (statusText.isNotEmpty()) statusText = ""
                        replaceAnswer(answerId, snapshot, false)
                    }
                }
            }
            try {
                if (offline) {
                    LocalLlm.stream(
                        cacheDir = getApplication<Application>().cacheDir.path,
                        modelPath = settings.localModelFile.path,
                        useGpu = settings.localGpu,
                        useVision = settings.localVision,
                        systemPrompt = settings.systemPrompt,
                        temperature = settings.temperature,
                        history = history,
                        onStatus = { s ->
                            viewModelScope.launch(Dispatchers.Main.immediate) { statusText = s }
                        },
                        onDelta = onDelta,
                    )
                } else {
                    GeminiClient.streamChat(
                        apiKey = settings.apiKey,
                        model = settings.model,
                        systemPrompt = settings.systemPrompt,
                        temperature = settings.temperature,
                        webSearch = settings.webSearch,
                        history = history,
                        onDelta = onDelta,
                    )
                }
                replaceAnswer(answerId, sb.toString(), false)
            } catch (e: CancellationException) {
                if (sb.isBlank()) removeAnswer(answerId) else replaceAnswer(answerId, sb.toString(), false)
            } catch (e: GeminiException) {
                finishWithError(answerId, sb, e.message ?: "Ошибка")
            } catch (e: LocalLlmException) {
                finishWithError(answerId, sb, e.message ?: "Ошибка")
            } catch (e: Exception) {
                finishWithError(answerId, sb, "Что-то пошло не так: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                // Если пользователь уже перешёл в другой чат, не трогаем его сообщения.
                if (currentId == chatId) {
                    isGenerating = false
                    statusText = ""
                    saveCurrent()
                }
            }
        }
    }

    private fun finishWithError(answerId: Long, sb: StringBuilder, message: String) {
        if (sb.isBlank()) {
            replaceAnswer(answerId, message, true)
        } else {
            replaceAnswer(answerId, sb.toString(), false)
            notice = message
        }
    }

    private fun replaceAnswer(id: Long, text: String, isError: Boolean) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text, isError = isError)
    }

    private fun removeAnswer(id: Long) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) messages.removeAt(i)
    }

    // ------------------------------------------------------------------
    // Офлайн-модель: выбор файла и удаление
    // ------------------------------------------------------------------

    fun importModel(uri: Uri) {
        if (importProgress != null) return
        val resolver = getApplication<Application>().contentResolver
        importJob = viewModelScope.launch {
            importProgress = 0f
            val target = settings.localModelFile
            val tmp = File(target.parentFile, "model.tmp")
            try {
                var name = "model.litertlm"
                var size = -1L
                withContext(Dispatchers.IO) {
                    resolver.query(uri, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            val s = c.getColumnIndex(OpenableColumns.SIZE)
                            if (n >= 0) name = c.getString(n) ?: name
                            if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
                        }
                    }
                }
                if (!name.endsWith(".litertlm", ignoreCase = true)) {
                    notice = "Нужен файл формата .litertlm (у выбранного файла другое расширение)"
                    return@launch
                }
                if (size > 0 && target.parentFile!!.usableSpace < size + 50L * 1024 * 1024) {
                    notice = "Не хватает места на телефоне: нужно ещё около ${(size / 1_000_000_000.0).format1()} ГБ"
                    return@launch
                }

                withContext(Dispatchers.IO) {
                    LocalLlm.unload()
                    resolver.openInputStream(uri)?.use { input ->
                        tmp.outputStream().use { output ->
                            val buf = ByteArray(1 shl 20)
                            var copied = 0L
                            var lastReported = -1
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                output.write(buf, 0, n)
                                copied += n
                                if (size > 0) {
                                    val pct = (copied * 100 / size).toInt()
                                    if (pct != lastReported) {
                                        lastReported = pct
                                        val p = copied.toFloat() / size
                                        viewModelScope.launch(Dispatchers.Main.immediate) { importProgress = p }
                                    }
                                }
                                ensureActive()
                            }
                        }
                    } ?: throw IllegalStateException("Не удалось открыть файл")
                    if (target.exists()) target.delete()
                    if (!tmp.renameTo(target)) throw IllegalStateException("Не удалось сохранить модель")
                }
                settings.setLocalModel(name, target.length())
                notice = "Модель добавлена: $name"
            } catch (e: CancellationException) {
                notice = "Копирование отменено"
            } catch (e: Exception) {
                notice = "Не удалось добавить модель: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                runCatching { tmp.delete() }
                importProgress = null
            }
        }
    }

    fun cancelImport() {
        importJob?.cancel()
    }

    fun deleteModel() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                LocalLlm.unload()
                runCatching { settings.localModelFile.delete() }
            }
            settings.clearLocalModel()
        }
    }

    private fun Double.format1(): String = "%.1f".format(this)

    override fun onCleared() {
        super.onCleared()
        saveCurrent()
    }

    companion object {
        const val MAX_IMAGES = 4
    }
}
