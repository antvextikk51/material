package com.example.aiagent.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.dp

private data class Block(val isCode: Boolean, val text: String)

private fun splitBlocks(src: String): List<Block> {
    val result = mutableListOf<Block>()
    val current = StringBuilder()
    var inCode = false
    for (line in src.split("\n")) {
        if (line.trimStart().startsWith("```")) {
            if (inCode) {
                result.add(Block(true, current.toString().trimEnd('\n')))
            } else if (current.isNotBlank()) {
                result.add(Block(false, current.toString().trimEnd('\n')))
            }
            current.clear()
            inCode = !inCode
        } else {
            current.append(line).append('\n')
        }
    }
    if (current.isNotBlank()) result.add(Block(inCode, current.toString().trimEnd('\n')))
    return result
}

private val inlineRegex = Regex("""\[([^\]]+)]\((https?://[^)\s]+)\)|\*\*(.+?)\*\*|`([^`]+)`|(?<![*\w])\*([^*\s][^*]*?)\*(?![*\w])""")

private fun inlineMarkdown(line: String, codeBg: Color, linkColor: Color): AnnotatedString =
    buildAnnotatedString {
        var last = 0
        for (m in inlineRegex.findAll(line)) {
            append(line.substring(last, m.range.first))
            val g = m.groupValues
            when {
                g[1].isNotEmpty() -> withLink(
                    LinkAnnotation.Url(
                        g[2],
                        TextLinkStyles(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)),
                    )
                ) { append(g[1]) }
                g[3].isNotEmpty() -> pushStyle(SpanStyle(fontWeight = FontWeight.Bold)).also { append(g[3]); pop() }
                g[4].isNotEmpty() -> pushStyle(
                    SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)
                ).also { append(g[4]); pop() }
                g[5].isNotEmpty() -> pushStyle(SpanStyle(fontStyle = FontStyle.Italic)).also { append(g[5]); pop() }
            }
            last = m.range.last + 1
        }
        append(line.substring(last))
    }

@Composable
fun MarkdownText(text: String, color: Color, modifier: Modifier = Modifier) {
    val blocks = remember(text) { splitBlocks(text) }
    val codeBg = MaterialTheme.colorScheme.surfaceContainerHighest
    val linkColor = MaterialTheme.colorScheme.primary
    Column(modifier = modifier, verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
        blocks.forEach { block ->
            if (block.isCode) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = block.text,
                        style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(12.dp),
                    )
                }
            } else {
                val annotated = remember(block.text, codeBg, linkColor) {
                    buildAnnotatedString {
                        val lines = block.text.split("\n")
                        lines.forEachIndexed { i, raw ->
                            val trimmed = raw.trimStart()
                            val indent = raw.length - trimmed.length
                            when {
                                trimmed.startsWith("### ") || trimmed.startsWith("## ") || trimmed.startsWith("# ") -> {
                                    val content = trimmed.trimStart('#').trim()
                                    pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                                    append(inlineMarkdown(content, codeBg, linkColor))
                                    pop()
                                }
                                trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                                    append(" ".repeat(indent.coerceAtMost(8)))
                                    append("•  ")
                                    append(inlineMarkdown(trimmed.drop(2), codeBg, linkColor))
                                }
                                else -> append(inlineMarkdown(raw, codeBg, linkColor))
                            }
                            if (i != lines.lastIndex) append("\n")
                        }
                    }
                }
                Text(
                    text = annotated,
                    style = MaterialTheme.typography.bodyLarge,
                    color = color,
                )
            }
        }
    }
}
