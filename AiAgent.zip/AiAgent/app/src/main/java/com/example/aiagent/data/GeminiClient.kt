package com.example.aiagent.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

class GeminiException(message: String) : Exception(message)

/**
 * Клиент Google Gemini API (бесплатный тариф через ключ из Google AI Studio).
 * Ответ приходит потоком (SSE), поэтому текст появляется по мере генерации.
 */
object GeminiClient {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    /** Сколько последних сообщений с фото отправлять вместе с историей. */
    private const val MAX_HISTORY_IMAGE_MESSAGES = 4

    suspend fun streamChat(
        apiKey: String,
        model: String,
        systemPrompt: String,
        temperature: Float,
        webSearch: Boolean,
        history: List<ChatMessage>,
        onDelta: (String) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val body = buildBody(systemPrompt, temperature, webSearch, history)
        val url = URL("$BASE${model.trim()}:streamGenerateContent?alt=sse")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        val sources = LinkedHashMap<String, String>()
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw GeminiException(humanError(code, err))
            }
            var gotText = false
            var blockReason: String? = null
            var finishReason: String? = null
            BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { reader ->
                while (true) {
                    coroutineContext.ensureActive()
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.removePrefix("data:").trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue
                    val json = try { JSONObject(payload) } catch (e: Exception) { continue }

                    json.optJSONObject("promptFeedback")?.optString("blockReason")
                        ?.takeIf { it.isNotEmpty() }?.let { blockReason = it }

                    val cands = json.optJSONArray("candidates") ?: continue
                    if (cands.length() == 0) continue
                    val cand = cands.getJSONObject(0)
                    cand.optString("finishReason").takeIf { it.isNotEmpty() }?.let { finishReason = it }

                    val parts = cand.optJSONObject("content")?.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val p = parts.getJSONObject(i)
                            if (p.optBoolean("thought", false)) continue
                            val t = p.optString("text", "")
                            if (t.isNotEmpty()) {
                                gotText = true
                                onDelta(t)
                            }
                        }
                    }
                    val chunks = cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
                    if (chunks != null) {
                        for (i in 0 until chunks.length()) {
                            val web = chunks.getJSONObject(i).optJSONObject("web") ?: continue
                            val uri = web.optString("uri")
                            if (uri.isNotEmpty() && !sources.containsKey(uri)) {
                                sources[uri] = web.optString("title").ifEmpty { uri }
                            }
                        }
                    }
                }
            }
            if (!gotText) {
                throw GeminiException(
                    when {
                        blockReason != null -> "Запрос заблокирован фильтрами безопасности ($blockReason)."
                        finishReason == "SAFETY" -> "Ответ заблокирован фильтрами безопасности."
                        else -> "Модель вернула пустой ответ. Попробуй переформулировать вопрос."
                    }
                )
            }
            if (sources.isNotEmpty()) {
                val sb = StringBuilder("\n\n**Источники:**")
                sources.entries.take(6).forEach { (uri, title) ->
                    sb.append("\n- [").append(title.replace("]", ")").replace("[", "(")).append("](").append(uri).append(")")
                }
                onDelta(sb.toString())
            }
        } catch (e: GeminiException) {
            throw e
        } catch (e: IOException) {
            coroutineContext.ensureActive()
            throw GeminiException("Нет соединения с сервером. Проверь интернет и попробуй ещё раз.")
        } finally {
            conn.disconnect()
        }
    }

    private fun buildBody(
        systemPrompt: String,
        temperature: Float,
        webSearch: Boolean,
        history: List<ChatMessage>,
    ): JSONObject {
        val usable = history.filter { !it.isError && (it.text.isNotBlank() || it.images.isNotEmpty()) }
        // Фото отправляем только для последних сообщений, чтобы запрос не раздувался.
        val withImages = usable.filter { it.images.isNotEmpty() }.takeLast(MAX_HISTORY_IMAGE_MESSAGES).map { it.id }.toSet()

        val contents = JSONArray()
        usable.forEach { m ->
            val parts = JSONArray()
            if (m.role == Role.USER && m.id in withImages) {
                m.images.forEach { path ->
                    val bytes = ImageUtils.readBytes(path) ?: return@forEach
                    parts.put(
                        JSONObject().put(
                            "inlineData",
                            JSONObject()
                                .put("mimeType", "image/jpeg")
                                .put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
                        )
                    )
                }
            }
            val text = when {
                m.text.isNotBlank() -> m.text
                m.role == Role.USER && m.images.isNotEmpty() && m.id !in withImages -> "[фото]"
                m.role == Role.USER && m.images.isNotEmpty() -> "Что на этом фото?"
                else -> ""
            }
            if (text.isNotBlank()) parts.put(JSONObject().put("text", text))
            if (parts.length() > 0) {
                contents.put(JSONObject().put("role", m.role).put("parts", parts))
            }
        }

        val root = JSONObject()
        root.put("contents", contents)
        if (systemPrompt.isNotBlank()) {
            root.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
        }
        root.put("generationConfig", JSONObject().put("temperature", temperature.toDouble()))
        if (webSearch) {
            root.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }
        return root
    }

    private fun humanError(code: Int, raw: String): String {
        val apiMessage = try {
            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: Exception) {
            ""
        }
        return when {
            code == 400 && apiMessage.contains("API key", ignoreCase = true) ->
                "Неверный API-ключ. Проверь его в настройках."
            code == 400 && apiMessage.contains("location", ignoreCase = true) ->
                "Gemini API недоступен в твоём регионе. Попробуй включить VPN."
            code == 400 -> "Некорректный запрос: ${apiMessage.ifEmpty { "ошибка 400" }}"
            code == 401 || code == 403 ->
                "Доступ запрещён (ключ неверный, не активен или регион не поддерживается). ${apiMessage}".trim()
            code == 404 -> "Модель не найдена. Выбери другую модель в настройках."
            code == 429 -> "Лимит бесплатного тарифа исчерпан. Подожди минуту или выбери другую модель."
            code >= 500 -> "Сервер Google временно недоступен. Попробуй позже."
            else -> "Ошибка $code. ${apiMessage}".trim()
        }
    }
}
