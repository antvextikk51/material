package com.example.aiagent.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Role {
    const val USER = "user"
    const val MODEL = "model"
}

data class ChatMessage(
    val id: Long,
    val role: String,
    val text: String,
    /** Пути к сохранённым (уже уменьшенным) фото. */
    val images: List<String> = emptyList(),
    val isError: Boolean = false,
)

/** Хранение истории чата в файле во внутренней памяти приложения. */
class ChatStore(context: Context) {
    private val file = File(context.applicationContext.filesDir, "chat.json")

    fun load(): List<ChatMessage> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val imgs = o.optJSONArray("images")
                    val list = buildList {
                        if (imgs != null) for (j in 0 until imgs.length()) {
                            val p = imgs.getString(j)
                            if (File(p).exists()) add(p)
                        }
                    }
                    add(
                        ChatMessage(
                            id = o.getLong("id"),
                            role = o.getString("role"),
                            text = o.getString("text"),
                            images = list,
                            isError = o.optBoolean("error", false),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(messages: List<ChatMessage>) {
        try {
            val arr = JSONArray()
            messages.filter { it.text.isNotBlank() || it.images.isNotEmpty() }.forEach { m ->
                arr.put(
                    JSONObject().apply {
                        put("id", m.id)
                        put("role", m.role)
                        put("text", m.text)
                        put("images", JSONArray(m.images))
                        put("error", m.isError)
                    }
                )
            }
            file.writeText(arr.toString())
        } catch (_: Exception) {
        }
    }
}
