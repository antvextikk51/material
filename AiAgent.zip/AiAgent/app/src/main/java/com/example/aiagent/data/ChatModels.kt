package com.example.aiagent.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Role {
    const val USER = "user"
    const val MODEL = "model"
}

data class ChatMessage(
    val id: Long,
    val role: String,
    val text: String,
    /** Пути к сохранённым (уже уменьшенным) фото. */
    val images: List<String> = emptyList(),
    val isError: Boolean = false,
)

/** Один чат в списке слева. */
data class Conversation(
    val id: Long,
    val title: String,
    val updatedAt: Long,
)

/**
 * Хранение чатов в файлах во внутренней памяти приложения:
 * chats_index.json — список чатов, chat_<id>.json — сообщения каждого чата.
 */
class ChatStore(context: Context) {
    private val dir = context.applicationContext.filesDir
    private val indexFile = File(dir, "chats_index.json")
    private val legacyFile = File(dir, "chat.json")

    private fun messagesFile(id: Long) = File(dir, "chat_$id.json")

    fun loadIndex(): List<Conversation> {
        val list = try {
            if (indexFile.exists()) {
                val arr = JSONArray(indexFile.readText())
                buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(Conversation(o.getLong("id"), o.getString("title"), o.getLong("updated")))
                    }
                }
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            emptyList()
        }
        if (list.isNotEmpty() || indexFile.exists()) return list.sortedByDescending { it.updatedAt }

        // Перенос единственного чата из первой версии приложения.
        if (legacyFile.exists()) {
            val old = parseMessages(legacyFile)
            if (old.isNotEmpty()) {
                val id = System.currentTimeMillis()
                saveMessages(id, old)
                val migrated = listOf(Conversation(id, "Прошлый чат", id))
                saveIndex(migrated)
                runCatching { legacyFile.delete() }
                return migrated
            }
        }
        return emptyList()
    }

    fun saveIndex(list: List<Conversation>) {
        try {
            val arr = JSONArray()
            list.forEach {
                arr.put(JSONObject().put("id", it.id).put("title", it.title).put("updated", it.updatedAt))
            }
            indexFile.writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    fun loadMessages(id: Long): List<ChatMessage> = parseMessages(messagesFile(id))

    private fun parseMessages(file: File): List<ChatMessage> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val imgs = o.optJSONArray("images")
                    val list = buildList {
                        if (imgs != null) for (j in 0 until imgs.length()) {
                            val p = imgs.getString(j)
                            if (File(p).exists()) add(p)
                        }
                    }
                    add(
                        ChatMessage(
                            id = o.getLong("id"),
                            role = o.getString("role"),
                            text = o.getString("text"),
                            images = list,
                            isError = o.optBoolean("error", false),
                        )
                    )
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveMessages(id: Long, messages: List<ChatMessage>) {
        try {
            val arr = JSONArray()
            messages.filter { it.text.isNotBlank() || it.images.isNotEmpty() }.forEach { m ->
                arr.put(
                    JSONObject().apply {
                        put("id", m.id)
                        put("role", m.role)
                        put("text", m.text)
                        put("images", JSONArray(m.images))
                        put("error", m.isError)
                    }
                )
            }
            messagesFile(id).writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    fun deleteChat(id: Long) {
        // Фото, прикреплённые к сообщениям этого чата, удаляем вместе с ним.
        ImageUtils.deleteFiles(loadMessages(id).flatMap { it.images })
        runCatching { messagesFile(id).delete() }
    }
}
