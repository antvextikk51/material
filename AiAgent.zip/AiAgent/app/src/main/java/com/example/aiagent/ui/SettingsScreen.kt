@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.aiagent.ui

import android.os.Build
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.aiagent.ChatViewModel
import com.example.aiagent.data.Palette
import com.example.aiagent.data.ThemeMode
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val s = vm.settings
    val uriHandler = LocalUriHandler.current
    var showKey by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                title = { Text("Настройки") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад")
                    }
                },
            )
        },
    ) { inner ->
        LazyColumn(
            modifier = Modifier
                .padding(inner)
                .fillMaxSize()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // ---------------- Внешний вид ----------------
            item {
                Section(title = "Внешний вид", icon = Icons.Rounded.Palette) {
                    Label("Тема")
                    val modes = listOf(
                        ThemeMode.SYSTEM to "Системная",
                        ThemeMode.LIGHT to "Светлая",
                        ThemeMode.DARK to "Тёмная",
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        modes.forEachIndexed { index, (key, label) ->
                            SegmentedButton(
                                selected = s.themeMode == key,
                                onClick = { s.updateThemeMode(key) },
                                shape = SegmentedButtonDefaults.itemShape(index, modes.size),
                            ) { Text(label, maxLines = 1) }
                        }
                    }

                    Label("Цветовая схема")
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        PaletteChip("Серая", s.palette == Palette.GREY) { s.updatePalette(Palette.GREY) }
                        PaletteChip("Сиреневая", s.palette == Palette.LILAC) { s.updatePalette(Palette.LILAC) }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            PaletteChip("Из обоев (Material You)", s.palette == Palette.DYNAMIC) {
                                s.updatePalette(Palette.DYNAMIC)
                            }
                        }
                    }

                    SwitchRow(
                        title = "Чёрный фон (AMOLED)",
                        subtitle = "Для тёмной темы: чисто чёрный фон экономит заряд на OLED-экранах",
                        checked = s.amoled,
                        onChange = s::updateAmoled,
                    )

                    Label("Размер текста: ${(s.textScale * 100).roundToInt()}%")
                    Slider(
                        value = s.textScale,
                        onValueChange = { s.updateTextScale((it * 20).roundToInt() / 20f) },
                        valueRange = 0.8f..1.4f,
                    )
                }
            }

            // ---------------- ИИ ----------------
            item {
                Section(title = "Искусственный интеллект", icon = Icons.Rounded.AutoAwesome) {
                    Label("API-ключ Google AI Studio (бесплатный)")
                    OutlinedTextField(
                        value = s.apiKey,
                        onValueChange = s::updateApiKey,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("AIza…") },
                        shape = RoundedCornerShape(20.dp),
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { showKey = !showKey }) {
                                Icon(
                                    if (showKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = if (showKey) "Скрыть ключ" else "Показать ключ",
                                )
                            }
                        },
                    )
                    TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) {
                        Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(8.dp))
                        Text("Получить ключ бесплатно")
                    }

                    Label("Модель")
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(
                            "gemini-flash-latest" to "Flash (быстрая)",
                            "gemini-flash-lite-latest" to "Flash-Lite (лёгкая)",
                            "gemini-pro-latest" to "Pro (умная)",
                        ).forEach { (id, title) ->
                            PaletteChip(title, s.model == id) { s.updateModel(id) }
                        }
                    }
                    OutlinedTextField(
                        value = s.model,
                        onValueChange = s::updateModel,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("ID модели") },
                        supportingText = { Text("Можно ввести любую модель Gemini вручную. Pro на бесплатном тарифе может быть недоступна.") },
                        shape = RoundedCornerShape(20.dp),
                    )

                    Label("Креативность ответов: ${"%.1f".format(s.temperature)}")
                    Slider(
                        value = s.temperature,
                        onValueChange = { s.updateTemperature((it * 10).roundToInt() / 10f) },
                        valueRange = 0f..2f,
                    )
                    Text(
                        "Меньше — точнее и суше, больше — свободнее и разнообразнее.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    SwitchRow(
                        title = "Поиск в интернете",
                        subtitle = "Агент сам ищет свежую информацию через Google Search и добавляет источники",
                        checked = s.webSearch,
                        onChange = s::updateWebSearch,
                    )

                    OutlinedTextField(
                        value = s.systemPrompt,
                        onValueChange = s::updateSystemPrompt,
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 8,
                        label = { Text("Инструкция для агента") },
                        shape = RoundedCornerShape(20.dp),
                    )

                    FilledTonalButton(onClick = { confirmReset = true }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(8.dp))
                        Text("Сбросить настройки ИИ")
                    }
                }
            }

            // ---------------- Данные ----------------
            item {
                Section(title = "Данные", icon = Icons.Rounded.DeleteSweep) {
                    Text(
                        "История чата и фото хранятся только на этом устройстве. " +
                            "Сообщения и фото отправляются в Google Gemini API для получения ответа.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(
                        onClick = { confirmClear = true },
                        enabled = vm.messages.isNotEmpty(),
                    ) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(8.dp))
                        Text("Очистить историю чата")
                    }
                }
            }

            item {
                Text(
                    "ИИ Агент 1.0 · Material Design 3 · Gemini API",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Очистить историю?") },
            text = { Text("Вся переписка и сохранённые фото будут удалены.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.clearChat()
                    confirmClear = false
                }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } },
        )
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Сбросить настройки ИИ?") },
            text = { Text("Модель, креативность, инструкция и поиск вернутся к значениям по умолчанию. API-ключ останется.") },
            confirmButton = {
                TextButton(onClick = {
                    s.resetAi()
                    confirmReset = false
                }) { Text("Сбросить") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun Section(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CookieShape(lobes = 8, depth = 0.06f),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(40.dp),
                ) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(10.dp),
                    )
                }
                Spacer(Modifier.size(12.dp))
                Text(title, style = MaterialTheme.typography.titleLarge)
            }
            content()
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun PaletteChip(title: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(title, maxLines = 1) },
        leadingIcon = if (selected) {
            { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
        } else null,
        shape = RoundedCornerShape(16.dp),
    )
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.size(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
