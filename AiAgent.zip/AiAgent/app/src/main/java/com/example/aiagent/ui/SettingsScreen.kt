@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.aiagent.ui

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.aiagent.ChatViewModel
import com.example.aiagent.data.APP_NAME
import com.example.aiagent.data.Palette
import com.example.aiagent.data.Provider
import com.example.aiagent.data.ThemeMode
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val s = vm.settings
    val uriHandler = LocalUriHandler.current
    var showKey by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var confirmDeleteModel by remember { mutableStateOf(false) }

    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                title = { Text("Настройки") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Назад")
                    }
                },
            )
        },
    ) { inner ->
        LazyColumn(
            modifier = Modifier
                .padding(inner)
                .fillMaxSize()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // ---------------- Внешний вид ----------------
            item {
                Section(title = "Внешний вид", icon = Icons.Rounded.Palette) {
                    Label("Тема")
                    val modes = listOf(
                        ThemeMode.SYSTEM to "Системная",
                        ThemeMode.LIGHT to "Светлая",
                        ThemeMode.DARK to "Тёмная",
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        modes.forEachIndexed { index, (key, label) ->
                            SegmentedButton(
                                selected = s.themeMode == key,
                                onClick = { s.updateThemeMode(key) },
                                shape = SegmentedButtonDefaults.itemShape(index, modes.size),
                            ) { Text(label, maxLines = 1) }
                        }
                    }

                    Label("Цветовая схема")
                    val palettes = buildList {
                        add(Palette.GREY to "Серая")
                        add(Palette.YELLOW to "Жёлтая")
                        add(Palette.RED to "Красная")
                        add(Palette.GREEN to "Зелёная")
                        add(Palette.LILAC to "Сиреневая")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) add(Palette.DYNAMIC to "Из обоев")
                    }
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        palettes.forEach { (key, title) ->
                            PaletteSwatch(
                                paletteKey = key,
                                title = title,
                                selected = s.palette == key,
                                onClick = { s.updatePalette(key) },
                            )
                        }
                    }

                    SwitchRow(
                        title = "Чёрный фон (AMOLED)",
                        subtitle = "Для тёмной темы: чисто чёрный фон экономит заряд на OLED-экранах",
                        checked = s.amoled,
                        onChange = s::updateAmoled,
                    )

                    Label("Размер текста: ${(s.textScale * 100).roundToInt()}%")
                    Slider(
                        value = s.textScale,
                        onValueChange = { s.updateTextScale((it * 20).roundToInt() / 20f) },
                        valueRange = 0.8f..1.4f,
                    )
                }
            }

            // ---------------- Источник ответов ----------------
            item {
                Section(title = "Источник ответов", icon = Icons.Rounded.AutoAwesome) {
                    val sources = listOf(Provider.OFFLINE to "Офлайн", Provider.GEMINI to "Gemini")
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        sources.forEachIndexed { index, (key, label) ->
                            SegmentedButton(
                                selected = s.provider == key,
                                onClick = { s.updateProvider(key) },
                                shape = SegmentedButtonDefaults.itemShape(index, sources.size),
                            ) { Text(label, maxLines = 1) }
                        }
                    }
                    Text(
                        if (s.provider == Provider.OFFLINE) {
                            "Ответы создаются прямо на телефоне: без интернета, без ключей, твои сообщения никуда не уходят."
                        } else {
                            "Ответы приходят из облака Google (Gemini). Нужен интернет и бесплатный ключ. " +
                                "Сообщения и фото отправляются в Google."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // ---------------- Офлайн-модель ----------------
            item {
                Section(title = "Офлайн-модель", icon = Icons.Rounded.Memory) {
                    val progress = vm.importProgress
                    if (s.hasLocalModel) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerHighest,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(s.localModelName, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Размер: ${formatSize(s.localModelSize)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    } else {
                        Text(
                            "Модель не выбрана. Без неё офлайн-режим не работает.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }

                    if (progress != null) {
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Копирую файл… ${(progress * 100).roundToInt()}%",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f),
                            )
                            TextButton(onClick = vm::cancelImport) { Text("Отмена") }
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(onClick = { pickModel.launch(arrayOf("*/*")) }) {
                                Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(if (s.hasLocalModel) "Заменить" else "Выбрать файл")
                            }
                            if (s.hasLocalModel) {
                                OutlinedButton(onClick = { confirmDeleteModel = true }) { Text("Удалить") }
                            }
                        }
                    }

                    Text(
                        "Как добавить модель:\n" +
                            "1. Открой Hugging Face (кнопка ниже) и найди модель в формате .litertlm. " +
                            "Подойдут Gemma 4 E2B-it (умнее, возможно, видит фото) или Qwen2.5-1.5B-Instruct " +
                            "(легче, только текст).\n" +
                            "2. Скачай файл на телефон.\n" +
                            "3. Нажми «Выбрать файл» и укажи его. Копия сохранится в памяти приложения, " +
                            "скачанный оригинал потом можно удалить.\n\n" +
                            "Файл занимает от 0.5 до нескольких ГБ. Для крупных моделей нужно от 6 ГБ " +
                            "оперативной памяти. Первый ответ после запуска приложения идёт дольше: модель загружается в память.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    TextButton(onClick = { uriHandler.openUri("https://huggingface.co/litert-community") }) {
                        Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Открыть Hugging Face: litert-community")
                    }

                    Label("Где считает модель")
                    val backends = listOf(false to "Процессор", true to "Видеоускоритель")
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        backends.forEachIndexed { index, (gpu, label) ->
                            SegmentedButton(
                                selected = s.localGpu == gpu,
                                onClick = { s.updateLocalGpu(gpu) },
                                shape = SegmentedButtonDefaults.itemShape(index, backends.size),
                            ) { Text(label, maxLines = 1) }
                        }
                    }
                    Text(
                        "Процессор работает везде. Видеоускоритель может быть быстрее, но не на всех телефонах: " +
                            "если не заработает, приложение само вернётся к процессору.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    SwitchRow(
                        title = "Фото в офлайн-режиме",
                        subtitle = "Работает, только если модель умеет смотреть картинки. Занимает больше памяти.",
                        checked = s.localVision,
                        onChange = s::updateLocalVision,
                    )
                }
            }

            // ---------------- Gemini (дополнение) ----------------
            item {
                Section(title = "Gemini (по желанию)", icon = Icons.Rounded.Cloud) {
                    Text(
                        "Умнее и быстрее офлайн-моделей, умеет смотреть фото и искать в интернете. " +
                            "Включается переключателем «Источник ответов» выше.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Label("API-ключ Google AI Studio (бесплатный)")
                    OutlinedTextField(
                        value = s.apiKey,
                        onValueChange = s::updateApiKey,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("AIza…") },
                        shape = RoundedCornerShape(20.dp),
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { showKey = !showKey }) {
                                Icon(
                                    if (showKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = if (showKey) "Скрыть ключ" else "Показать ключ",
                                )
                            }
                        },
                    )
                    TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) {
                        Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Получить ключ бесплатно")
                    }

                    Label("Модель Gemini")
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(
                            "gemini-flash-latest" to "Flash (быстрая)",
                            "gemini-flash-lite-latest" to "Flash-Lite (лёгкая)",
                            "gemini-pro-latest" to "Pro (умная)",
                        ).forEach { (id, title) ->
                            ModelChip(title, s.model == id) { s.updateModel(id) }
                        }
                    }
                    OutlinedTextField(
                        value = s.model,
                        onValueChange = s::updateModel,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("ID модели") },
                        supportingText = {
                            Text("Можно ввести любую модель Gemini вручную. Pro на бесплатном тарифе может быть недоступна.")
                        },
                        shape = RoundedCornerShape(20.dp),
                    )

                    SwitchRow(
                        title = "Поиск в интернете",
                        subtitle = "Gemini сам ищет свежую информацию через Google Search и добавляет источники",
                        checked = s.webSearch,
                        onChange = s::updateWebSearch,
                    )
                }
            }

            // ---------------- Общее для ответов ----------------
            item {
                Section(title = "Поведение ассистента", icon = Icons.Rounded.Tune) {
                    Label("Креативность ответов: ${"%.1f".format(s.temperature)}")
                    Slider(
                        value = s.temperature,
                        onValueChange = { s.updateTemperature((it * 10).roundToInt() / 10f) },
                        valueRange = 0f..2f,
                    )
                    Text(
                        "Меньше — точнее и суше, больше — свободнее и разнообразнее. Действует и офлайн, и в Gemini.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    OutlinedTextField(
                        value = s.systemPrompt,
                        onValueChange = s::updateSystemPrompt,
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 8,
                        label = { Text("Инструкция для $APP_NAME") },
                        shape = RoundedCornerShape(20.dp),
                    )

                    FilledTonalButton(onClick = { confirmReset = true }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Сбросить настройки ИИ")
                    }
                }
            }

            // ---------------- Данные ----------------
            item {
                Section(title = "Данные", icon = Icons.Rounded.DeleteSweep) {
                    Text(
                        "История чатов и фото хранятся только на этом устройстве. " +
                            "В режиме Gemini сообщения и фото отправляются в Google, в офлайн-режиме никуда не уходят.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(
                        onClick = { confirmClear = true },
                        enabled = vm.conversations.isNotEmpty(),
                    ) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Удалить все чаты")
                    }
                }
            }

            item {
                Text(
                    "$APP_NAME 1.1 · Material Design 3",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    textAlign = TextAlign.Center,
                )
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Удалить все чаты?") },
            text = { Text("Вся переписка и сохранённые фото будут удалены без возможности восстановления.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteAllChats()
                    confirmClear = false
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } },
        )
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Сбросить настройки ИИ?") },
            text = {
                Text(
                    "Модель Gemini, креативность, инструкция, поиск, режим вычислений и фото вернутся к значениям " +
                        "по умолчанию. Ключ и офлайн-модель останутся."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    s.resetAi()
                    confirmReset = false
                }) { Text("Сбросить") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Отмена") } },
        )
    }
    if (confirmDeleteModel) {
        AlertDialog(
            onDismissRequest = { confirmDeleteModel = false },
            title = { Text("Удалить офлайн-модель?") },
            text = { Text("Файл модели будет удалён из памяти приложения. Потом его можно выбрать снова.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteModel()
                    confirmDeleteModel = false
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { confirmDeleteModel = false }) { Text("Отмена") } },
        )
    }
}

private fun formatSize(bytes: Long): String {
    val gb = bytes / 1_000_000_000.0
    return if (gb >= 1.0) "%.2f ГБ".format(gb) else "%d МБ".format((bytes / 1_000_000.0).roundToInt())
}

/** Образец цветовой схемы: круглая «печенька» основного цвета на фоне контейнера. */
@Composable
private fun PaletteSwatch(paletteKey: String, title: String, selected: Boolean, onClick: () -> Unit) {
    val context = LocalContext.current
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val scheme = if (paletteKey == Palette.DYNAMIC && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        paletteScheme(paletteKey, dark)
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(4.dp),
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = scheme.primaryContainer,
            border = if (selected) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null,
            modifier = Modifier.size(68.dp),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CookieShape(lobes = 8, depth = 0.07f))
                        .background(scheme.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    if (selected) {
                        Icon(
                            Icons.Rounded.Check,
                            contentDescription = null,
                            tint = scheme.onPrimary,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
            }
        }
        Spacer(Modifier.size(6.dp))
        Text(
            title,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
    }
}

@Composable
private fun Section(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CookieShape(lobes = 8, depth = 0.06f),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(40.dp),
                ) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(10.dp),
                    )
                }
                Spacer(Modifier.width(12.dp))
                Text(title, style = MaterialTheme.typography.titleLarge)
            }
            content()
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun ModelChip(title: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(title, maxLines = 1) },
        leadingIcon = if (selected) {
            { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
        } else null,
        shape = RoundedCornerShape(16.dp),
    )
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
